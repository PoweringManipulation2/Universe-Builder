# Character Mode

Builds a single, independent character card (Schema 1). Everything lives
inside the card's main fields. No embedded lorebook.

## Field Reference

| Field                 | Content                                                    | Tokens    |
|-----------------------|------------------------------------------------------------|-----------|
| `name`                | Character name                                             | —         |
| `description`         | Complete character: appearance, personality, voice, role, relationships, clothing, items, secrets, behavior. Write until complete. | Variable |
| `personality`         | Terse core trait summary, punchy, 1–3 lines                | 50–100    |
| `scenario`            | ONLY if user explicitly requests it                        | 50–150    |
| `first_mes`           | In-scene opener, character present and active, voice distinct from line one | 100–250 |
| `alternate_greetings` | 2–3 genuinely different openers — different mood, context, or register | 100–250 each |
| `mes_example`         | 3–5 exchanges showing voice and behavior, not plot         | 150–350   |
| `creator_notes`       | Structured AI instructions. One rule per line, action-first | 100–200   |

## Description Structure

Write in this order, as flowing prose (not labeled sections):

1. **IDENTITY** → Role, archetype, function in the world
2. **TEMPORAL CONTEXT** → When this character is active. If from an existing property,
   note the time period, current status (alive/dead/missing), and where they are during
   the relevant story timeframe. Weave naturally into the description.
3. **APPEARANCE** → Full physical detail. Minimum 3–4 sentences.
4. **VOICE** → Speech patterns, vocabulary, verbal tics, what they never say
5. **PERSONALITY** → Natural language prose. Never lists.
6. **HISTORY** → Where they came from, key events that shaped them, turning points.
   Even a brief character deserves at least 1–2 sentences of backstory.
7. **HOME** → Where they live or spend their time. What their space says about them.
8. **RELATIONSHIPS** → Key bonds woven into prose. Soft references only (no lorebook recursion in Schema 1).
9. **CLOTHING** → Woven into prose, not enumerated
10. **ITEMS** → Carried objects written naturally
11. **SECRETS** → What they hide / don't know about themselves
12. **BEHAVIOR** → Under pressure, in intimacy, in conflict

## Writing Rules

- Transform input into evocative prose. Don't copy user's wording verbatim.
- Open with presence, not taxonomy:
  - ✅ "She moves through a crowd like the crowd already knows to step aside."
  - ❌ "She is a tall woman with dark hair."
- `first_mes` opens in-scene. Never "Hello, I am X."
- `alternate_greetings`: genuinely different scenes — different location, mood, or stakes.
- `mes_example` format:
  ```
  <START>
  {{user}}: [User line]
  {{char}}: [Response — voice, not plot.]
  ```
- `creator_notes`: instructions TO the AI, not narrative. Imperative, action-first.

## No Batching Needed

Character Mode produces a single card (Schema 1). Output in one generation.
No phased generation, no merge step.

Read `references/schemas.md` for Schema 1 structure before generating.
