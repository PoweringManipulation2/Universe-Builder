# Persona Mode

Builds a User Persona in plain text for SillyTavern's persona description field.
No JSON wrapper.

## Description Structure

| Section      | Content                                         |
|--------------|-------------------------------------------------|
| IDENTITY     | Role, background, origin                        |
| TEMPORAL     | Time period active, current status and location |
| APPEARANCE   | Physical detail. Minimum 2–3 sentences.         |
| PERSONALITY  | Prose. Never trait lists.                        |
| HISTORY      | Background, origin story, key events. Min 1–2 sentences. |
| HOME         | Where they live, what the space says about them |
| VOICE        | Vocabulary, tone, verbal habits                 |
| SKILLS       | Grounded and specific capabilities              |
| QUIRKS       | Small behavioral details for realism            |
| ITEMS        | Woven naturally into prose                      |

## Rules

- 3rd person default, 1st person if user prefers
- Prose must be actionable — AI should infer reactions from description
- 150–400 tokens standard. Full Detail removes ceiling.
- No first_mes or greeting fields.

## Output Format

```
[Character Name]
[Full description prose — plain text, no JSON]
```

## Persona Lorebook (Optional)

If persona needs a lorebook, output separately as Schema 3 AFTER the
plain-text persona: `── STANDALONE LOREBOOK (import via World Info) ──`

Don't generate persona lorebook automatically. Only suggest when persona has
complex backstory, unique items, or relationships benefiting from keyword-triggered loading.

### Persona Lorebook Interaction (when both persona + world lorebook active)

**Keyword collision prevention:** Use persona-specific keywords (name, unique items,
personal locations). Avoid generic keywords shared with world lorebook.

**Namespace:** Prefix persona entry comments with `"PERSONA:"` —
e.g., `comment: "PERSONA: Kael's Backstory"`

**Content ownership:**
- Persona lorebook: personal history, private relationships, internal motivations,
  unique items, past-only places. Things relevant only when playing AS this persona.
- World lorebook: anything existing independently — factions, NPCs, locations, rules.

**Insertion order:** 600–699 range (protagonist tier).

## No Batching Needed

Persona Mode produces plain text (+ optional small lorebook). No phased generation needed.
