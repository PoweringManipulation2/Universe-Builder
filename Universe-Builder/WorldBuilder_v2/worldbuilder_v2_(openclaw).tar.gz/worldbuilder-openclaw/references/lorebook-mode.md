# Lorebook Mode

Builds a standalone World Info JSON (Schema 3) using keyed entries object,
for import via the World Info panel. No character card wrapper.

## When to Use

- User wants a lorebook without a card
- TTRPG systems, encyclopedias, world bibles with no narrative arc
- Supplementary lore for an existing card setup
- "lorebook" or "standalone lorebook"

## First Question: Tailored or Universal?

When the user enters Lorebook Mode, immediately ask:

"Is this lorebook tailored for a specific world or character, or is it a universal
lorebook — like a collection of items, rules, concepts, or lore that isn't tied to
one setting?"

### Tailored Lorebook

Built for a known franchise, specific original world, or a specific character's
context. Uses the standard four-layer architecture with factions, characters,
locations. Follows the normal pre-generation workflow — if it's a known property,
web search verification applies.

Examples: "a lorebook for the Witcher universe", "lore entries for my OC's world",
"supplementary entries for my existing Game of Thrones card."

### Universal Lorebook

A freestanding collection not anchored to one narrative world. The architecture
adapts — the four layers still exist but serve different purposes:

- **Layer 1**: System rules, universal constraints, core mechanics
- **Layer 2**: Category anchors (replaces faction anchors) — organize by domain.
  Examples: "Weapon Types", "Schools of Magic", "Potion Categories", "Monster Families"
- **Layer 3**: Detailed reference entries — full articles per topic
- **Layer 4**: Sub-entries — individual items, spells, minor entries. Leaf nodes.

A universal lorebook might contain ONLY items, or ONLY concepts, or ONLY rules,
or a mix. The user decides what categories exist. Not every layer needs to be used —
an items-only lorebook might just be Layer 2 category anchors + Layer 4 item entries.

"Prose over lists" relaxes for mechanical/reference info (stats, abilities, costs).

Because universal lorebooks have no canonical source to search against, they follow
the **Original / Universal Build Workflow** described in SKILL.md — the user is the
source of truth, and the batch loop uses list-referencing instead of web search.

## Critical: Schema 3 Field Names

Standalone uses DIFFERENT field names from embedded. Wrong names cause
silent import failure. Read `references/schemas.md` carefully.

Key differences from embedded (Schema 2):
- `"key"` not `"keys"`
- `"keysecondary"` not `"secondary_keys"`
- `"order"` not `"insertion_order"`
- `"position": 0` (before) or `1` (after) — integers, not strings
- `"disable": true` not `"enabled: false"`
- `"preventRecursion"` not `"prevent_recursion"`
- Container is `entries: { "0": {...}, "1": {...} }` — object with string keys, not array

## Lorebook Architecture

Uses the same four-layer recursive tree as World Mode (adapted for universal builds).
Read `references/lorebook-architecture.md` for full details.

## Batch Generation

Lorebook Mode uses the automated batch pipeline. Phase files contain
Schema 3 entry objects that get merged into the final lorebook.

For universal lorebooks and original concepts, the batch loop replaces web search
verification with list-referencing — see "Original / Universal Build Workflow" in SKILL.md.

## Phase File Format (Schema 3)

Each phase file for standalone lorebooks uses this format:

```json
{
  "entries": {
    "10": { ... },
    "11": { ... },
    "12": { ... }
  }
}
```

The merge script combines all phase entries into the final lorebook shell.
