# JSON Schemas Reference

Three schemas used across modes. Using the wrong one causes import failures.

**V3 is now the primary target.** SillyTavern reads V3 (`ccv3` chunk) preferentially
over V2 (`chara` chunk). V3 is backward-compatible with V2 — all V2 fields remain,
plus new fields. The skill outputs V3 JSON with V1 backfill fields at the top level
for maximum compatibility with older editors and frontends.

---

## Schema 1 — Single Character Card (Character Mode)

No embedded lorebook. `character_book` omitted entirely.
`scenario` included ONLY if user explicitly requests it.

```json
{
  "name": "",
  "description": "",
  "personality": "",
  "first_mes": "",
  "mes_example": "",
  "creatorcomment": "",
  "avatar": "none",
  "chat": "",
  "talkativeness": "0.5",
  "fav": false,
  "spec": "chara_card_v3",
  "spec_version": "3.0",
  "data": {
    "name": "",
    "description": "",
    "personality": "",
    "first_mes": "",
    "mes_example": "",
    "creator_notes": "",
    "system_prompt": "",
    "post_history_instructions": "",
    "tags": [],
    "creator": "",
    "character_version": "",
    "alternate_greetings": [],
    "group_only_greetings": [],
    "extensions": {},
    "assets": [],
    "nickname": "",
    "creator_notes_multilingual": {},
    "source": [],
    "creation_date": 0,
    "modification_date": 0
  }
}
```

- `chat`: ST assigns automatically — leave empty.
- `character_version`: date string or semantic version.
- Do NOT include `character_book` in Schema 1.
- Do NOT include `scenario` unless user explicitly asked for it.
- `creation_date` / `modification_date`: Unix timestamps in seconds (UTC). Set
  `creation_date` at generation time. Set `modification_date` to same value initially.
- `group_only_greetings`: greetings that only appear in group chat contexts. Empty
  array if not applicable.
- `assets`: array of asset objects `{type, uri, name, ext}`. Leave empty for JSON-only
  output (assets are primarily useful for CHARX/PNG packaging).
- `nickname`: optional display name override. Leave empty string if same as `name`.
- `source`: array of source URLs or references. Optional.
- `creator_notes_multilingual`: Record of language code to creator notes. Optional.

### V1 Backfill

The top-level fields (`name`, `description`, `personality`, `first_mes`, `mes_example`)
duplicate the same fields inside `data`. This is V1 backfill — older frontends read
these top-level fields. Always keep them in sync with `data.*` values.

---

## Schema 2 — World Card with Embedded Lorebook (World Mode)

Narrator/world card. `character_book` REQUIRED. `scenario` STRIPPED entirely.

```json
{
  "name": "",
  "description": "",
  "personality": "",
  "first_mes": "",
  "mes_example": "",
  "creatorcomment": "",
  "avatar": "none",
  "chat": "",
  "talkativeness": "0.5",
  "fav": false,
  "spec": "chara_card_v3",
  "spec_version": "3.0",
  "data": {
    "name": "",
    "description": "",
    "personality": "",
    "first_mes": "",
    "mes_example": "",
    "creator_notes": "",
    "system_prompt": "",
    "post_history_instructions": "",
    "tags": [],
    "creator": "",
    "character_version": "",
    "alternate_greetings": [],
    "group_only_greetings": [],
    "character_book": {
      "name": "",
      "description": "",
      "scan_depth": 0,
      "token_budget": 0,
      "recursive_scanning": true,
      "extensions": {},
      "entries": []
    },
    "extensions": {},
    "assets": [],
    "nickname": "",
    "creator_notes_multilingual": {},
    "source": [],
    "creation_date": 0,
    "modification_date": 0
  }
}
```

### Embedded Entry Object (inside `character_book.entries` array):

```json
{
  "id": 0,
  "keys": ["keyword1", "keyword2"],
  "secondary_keys": [],
  "comment": "Entry Name - Category",
  "content": "...",
  "constant": false,
  "selective": false,
  "selectiveLogic": 0,
  "insertion_order": 100,
  "priority": 100,
  "position": "after_char",
  "enabled": true,
  "probability": 100,
  "use_regex": false,
  "case_sensitive": false,
  "name": "",
  "depth": 4,
  "sticky": 0,
  "vectorized": false,
  "exclude_recursion": false,
  "prevent_recursion": false,
  "extensions": {
    "uid": 0,
    "addMemo": true,
    "useProbability": true,
    "ignoreBudget": false
  }
}
```

**ID/UID RULE**: `id` and `extensions.uid` must be unique across all entries and increment together from 0.

**V3 changes in entries:**
- `use_regex`: now REQUIRED (was optional in V2). Default `false` for standard builds.
  See "Regex Keywords" section below.
- `priority`: V3 adds this field alongside `insertion_order`. When token budget is
  exceeded, entries with lower `priority` values are dropped first. Set `priority`
  equal to `insertion_order` unless you have a specific reason to diverge — this
  keeps behavior predictable.
- `name`: V3 adds this optional field for entry identification. Set it to the entry
  name (same as `comment` without the category suffix). Not used in prompting.

**Dynamic fields:**
- `position` → `"before_char"` or `"after_char"`
- `selective` → `true` ONLY when `secondary_keys` has values
- `constant` → `true` ONLY for Layer 1 and Layer 2 entries
- `enabled` → ALWAYS `true` — never omit this field
- `sticky` → 0 default; 3–5 brief; 5–8 combat; 15+ permanent
- `depth` → Match global `scan_depth` unless per-entry override needed

---

## Schema 3 — Standalone Lorebook (Lorebook Mode, Group Chat shared lorebook)

Keyed OBJECT `Record<number, entry>`, NOT an array. Field names differ from embedded.

```json
{
  "name": "",
  "scan_depth": 0,
  "token_budget": 0,
  "recursive_scanning": true,
  "entries": {
    "0": {
      "uid": 0,
      "key": ["keyword1", "keyword2"],
      "keysecondary": [],
      "comment": "Entry Name - Category",
      "content": "...",
      "constant": false,
      "selective": false,
      "selectiveLogic": 0,
      "addMemo": true,
      "order": 100,
      "position": 0,
      "disable": false,
      "excludeRecursion": false,
      "preventRecursion": false,
      "probability": 100,
      "useProbability": true,
      "depth": 4,
      "group": "",
      "groupWeight": 100,
      "scanDepth": null,
      "caseSensitive": null,
      "matchWholeWords": null,
      "useGroupScoring": null,
      "displayIndex": 0,
      "sticky": 0,
      "cooldown": 0,
      "delay": 0
    }
  }
}
```

### CRITICAL Field Differences — Embedded vs. Standalone

| Concept              | Embedded (Schema 2)         | Standalone (Schema 3)       |
|----------------------|-----------------------------|-----------------------------|
| Container            | `entries: [ {...}, {...} ]`  | `entries: { "0": {...} }`   |
| Trigger keywords     | `"keys": []`                | `"key": []`                 |
| Optional filter      | `"secondary_keys": []`      | `"keysecondary": []`        |
| Priority / order     | `"insertion_order": 100`    | `"order": 100`              |
| Position             | `"position": "after_char"`  | `"position": 1`             |
| Disabled             | `"enabled": false`          | `"disable": true`           |
| Recursion block      | `"prevent_recursion": true` | `"preventRecursion": true`  |
| Recursion exclude    | `"exclude_recursion": true` | `"excludeRecursion": true`  |
| Entry identifier     | `"id"` + `"extensions.uid"` | object key + `"uid"`        |

Using the wrong field names causes silent import failures or data loss.

### Standalone-specific fields:
- `scanDepth` → `null` = use global, integer = override
- `caseSensitive` → `null` = use global, boolean = override
- `matchWholeWords` → `null` = use global, boolean = override
- `cooldown` → messages entry cannot re-trigger after expiry
- `delay` → minimum messages before entry can activate

---

## Regex Keywords

`use_regex` is required in V3 entries. Default to `false` for all standard builds.

Regex keywords are a power-user feature. When `use_regex: true`, the `keys` array
contains regex patterns instead of plain strings, allowing pattern matching for
conjugations, partial names, possessives, and complex triggers.

**When to use regex:**
- The user explicitly asks for regex triggers
- A character has many name variants that are hard to cover with plain keywords
  (e.g. `/[Vv]oss(?:'s)?/` covers "Voss", "voss", "Voss's" in one pattern)
- Matching verb conjugations or word families

**When NOT to use regex (default):**
- Standard builds — plain keywords with secondary filtering handle 95% of cases
- Users who haven't specifically asked for it
- When keywords are unambiguous proper nouns

If using regex, warn the user in post-generation settings that regex keywords are
active, as they can cause unexpected behavior if patterns are too broad. Applications
may reject overly complex or ReDoS-vulnerable patterns.

---

## Entry Groups and Group Weight (60+ Entries)

For builds under 60 entries, leave `group: ""` and `groupWeight: 100` — the standard
insertion order and priority system handles budget allocation fine.

For massive builds (60+ entries), entry groups help manage token budget by grouping
related entries and controlling how much budget each group can consume.

**How groups work:**
- Entries with the same `group` string belong to the same group
- When multiple entries in a group trigger simultaneously, `groupWeight` determines
  which entries within the group get priority for budget allocation
- `groupWeight` is a relative value within the group (not a percentage of total budget)
- Higher `groupWeight` = more likely to be included when budget is tight

**Recommended group structure for large builds:**

| Group name          | Contents                              | groupWeight guidance      |
|---------------------|---------------------------------------|---------------------------|
| `"world-rules"`     | Layer 1 constant rules                | 100 (always include)      |
| `"faction-anchors"` | Layer 2 constant faction anchors      | 100 (always include)      |
| `"main-cast"`       | Tier A characters                     | 80-100                    |
| `"supporting-cast"` | Tier B characters                     | 50-80                     |
| `"background-cast"` | Tier C characters                     | 30-50                     |
| `"locations"`       | Layer 4 locations                     | 40-60                     |
| `"items"`           | Layer 4 items                         | 20-40                     |
| `"events"`          | Layer 4 timeline events               | 20-30                     |
| `"concepts"`        | Layer 4 concepts/terms                | 10-20                     |

For builds under 60 entries, skip groups entirely. The added complexity isn't worth it
for smaller builds where budget pressure is minimal.

Only apply groups to Schema 3 (standalone lorebooks). Schema 2 embedded lorebooks use
the `extensions` field for ST-specific group data if needed, but this is less common.

---

## Dynamic Sizing

Calculate AFTER generation based on actual build. Never use fixed defaults.

### Token Budget

| Build size                        | Budget  |
|-----------------------------------|---------|
| Under 10 entries, few constants   | 1024    |
| 10-20 entries, 2-4 constants      | 2048    |
| 20-35 entries, 4-6 constants      | 3072    |
| 35-50 entries, 6-10 constants     | 4096    |
| 50+ entries or 10+ constants      | 4096-6144 |
| Full Detail Mode                  | 4096 min; 6144+ if constants > 2048 tokens |

If constants consume >60% of budget → budget too low.

### Scan Depth

| Cast size      | Depth |
|----------------|-------|
| Small (<8)     | 2-3   |
| Medium (8-15)  | 4     |
| Large (15-30)  | 5-6   |
| Massive (30+)  | 6-8   |
| Full Detail    | 6 min |

Location-heavy worlds: +1-2 for persistence.

Values go into JSON output AND post-generation settings block.
