# Lorebook Architecture — Recursive Tree Hybrid

Used by World Mode (embedded) and Lorebook Mode (standalone).

## The Core Principle

Card description stays lean (world primer + protagonist appearance only).
Lorebook uses a recursive tree to surface content dynamically — only loading
what's relevant to the current chat moment.

Recursion MUST be enabled (`recursive_scanning: true`). Scan depth set via
Dynamic Sizing. If entries seem missed, raise `scan_depth` before changing keywords.

## The Four Entry Layers

### Layer 1 — WORLD RULES (constant, always loaded)

Core rules AI must never violate. Keep small — every token costs budget permanently.

- Format: `RULE:` prefix, absolute language (MUST, CANNOT, WILL INSTANTLY)
- `constant: true` | `prevent_recursion: true` | `position: before_char`
- `insertion_order` / `order`: 900–999
- Depth: global scan_depth + 1–2 (rules never "fade")

### Layer 2 — FACTION / CAST ANCHORS (constant, always loaded)

One entry per faction. Names every member (this seeds recursion chains).
Include purpose, structure, one rival/allied group.

- `constant: true` | `prevent_recursion: false` | `position: before_char`
- `insertion_order` / `order`: 700–899
- Keep concise — naming members matters more than lengthy prose

No factions: use role-based anchors — "The Protagonists", "The Antagonists",
"The Supporting Cast". No factions at all: relationship-based anchors —
"The Whitfield Family", "City Hall Staff". Job is the same: name everyone for recursion.

**Fluid / overlapping factions:**
- Multiple factions: name character in every anchor they belong to
- Layer 3 entry is single source of truth for actual loyalty
- Double agents/spies: name in PUBLIC faction anchor only. True allegiance in Layer 3 SECRETS

**Example:**
```
"The Iron Vanguard — military faction, enforces order in the outer districts.
Members: Commander Sera Voss, Lieutenant Davan Rhel, Archivist Nuno Cael,
Recruit Maren Thay. Rivals the Hollow Court. Controls the eastern gate."
```

### Layer 3 — CHARACTER ENTRIES (keyword-triggered)

One entry per character. Fires when name appears in scanned messages.

- `constant: false` | `prevent_recursion: false` | `position: after_char`
- Major characters: `insertion_order` 400–599
- Protagonist: 600–699
- Historical characters: 20–49 (and `prevent_recursion: true`)

Content structure:
- **TEMPORAL CONTEXT** → When this character is active. Status: alive/dead/missing.
  Active period. Current location. If dead: when and how (briefly). Weave into prose.
- **APPEARANCE** → Full physical detail. 3–4 sentences major, 2+ sentences minor.
- **PERSONALITY** → Prose only. Never trait lists.
- **HISTORY** → Background, origin, key events. At least 1–2 sentences for any character.
- **HOME** → Where they live or base themselves. What the space says about them.
- **BEHAVIOR** → Under pressure, in intimacy, in conflict.
- **VOICE** → Speech patterns, verbal tics, vocabulary register.
- **RELATIONSHIPS** → Key bonds as prose. Name people (enables recursion).
- **CLOTHING** → Woven into prose.
- **ITEMS** → Written naturally.
- **SECRETS** → What they hide or don't know about themselves.

### Layer 4 — LOCATIONS, ITEMS, FACTIONS (DETAIL), EVENTS, CONCEPTS

Fires on name in scanned messages.

- `constant: false` | `position: after_char`
- Depth: global scan_depth - 1 (fade faster)

| Type            | prevent_recursion | insertion_order | Notes                        |
|-----------------|-------------------|-----------------|------------------------------|
| Locations       | false             | 300–399         | Name NPCs and items present  |
| Items           | true              | 100–149         | What, what it does, who has it |
| Faction detail  | false             | 250–299         | Extended lore, politics      |
| Timeline events | true              | 50–99           | Use sticky values            |
| Concepts/terms  | true              | 1–19            | World systems, terminology   |

---

## Recursion in Practice

```
"the Iron Vanguard" mentioned
  → Layer 2 anchor loaded (constant, always there)
  → "Commander Voss" in anchor → Layer 3 Voss fires
    → Voss mentions "eastern gate" + "Davan Rhel"
      → Layer 4 eastern gate fires
      → Layer 3 Rhel fires
        → Rhel mentions "Vanguard's armory" → Layer 4 armory fires
```

Rich, relevant world slice from a single mention. Unmentioned characters
stay dark, cost zero tokens.

---

## Keyword & Recursion Guidelines

- 2–5 keywords per entry covering natural name variations
- Include possessives: `["Kael", "Kael's"]`
- Include titles: `["Commander Voss", "Voss", "the Commander"]`
- Faction anchors: faction name + shorthand: `["Iron Vanguard", "the Vanguard", "Vanguard soldiers"]`
- Never use a single generic word as sole keyword: `["warrior"]`, `["sword"]`
- Locations: place name + nicknames used in-world
- Match how AI and user will naturally refer to things

### Secondary Keys (Selective Filtering)

Purpose: solve keyword ambiguity when a primary keyword is too common.
Entry fires only when BOTH a primary AND secondary key appear.
Set `selective: true` when secondary keys are used.

**When to use:**
- Ambiguous names: "The Ring" (location) → `secondary_keys: ["arena", "fighting", "district"]`
- Shared names: "Blackwood" (person AND forest) → character uses `["lord", "father"]`, location uses `["forest", "woods"]`
- Generic item names: "The Crown" → `["coronation", "vault", "ancient"]`

**When NOT to use:**
- Primary keywords already unambiguous
- On constant entries (Layer 2) — secondary keys have no effect
- When it would make the entry effectively dead (too hard to trigger)

`selectiveLogic` values:
- 0 = AND ANY (primary + ANY secondary) — default for disambiguation
- 1 = NOT ALL (primary but NOT ALL secondary present)
- 2 = NOT ANY (primary but NONE of secondary present)
- 3 = AND ALL (primary + ALL secondary — very restrictive, rarely useful)

---

## Insertion Order Tiers

| Layer / Category              | insertion_order / order |
|-------------------------------|------------------------|
| World Rules (Layer 1)         | 900–999                |
| World State (if included)     | 950+                   |
| Faction / Cast Anchors (L2)   | 700–899                |
| Protagonist entry             | 600–699                |
| Major character entries       | 400–599                |
| Major location entries        | 300–399                |
| Faction detail entries        | 250–299                |
| Standard character entries    | 150–249                |
| Items                         | 100–149                |
| Timeline / event entries      | 50–99                  |
| Historical character entries  | 20–49                  |
| Concept / term entries        | 1–19                   |

Spread entries across tier. Never assign same value to two entries.
60+ entries: consider increments of 1 from start.

---

## Entry Type Quick Reference

| Type                  | Layer | constant | prevent_recursion | position    |
|-----------------------|-------|----------|-------------------|-------------|
| World Rules           | 1     | true     | true              | before_char |
| World State           | 1     | true     | true              | before_char |
| Faction/Cast Anchor   | 2     | true     | false             | before_char |
| Character (major)     | 3     | false    | false             | after_char  |
| Character (minor)     | 3     | false    | false             | after_char  |
| Character (hist.)     | 3     | false    | true              | after_char  |
| Location              | 4     | false    | false             | after_char  |
| Item                  | 4     | false    | true              | after_char  |
| Faction (detail)      | 4     | false    | false             | after_char  |
| Timeline Event        | 4     | false    | true              | before_char |
| Concept / Term        | 4     | false    | true              | after_char  |

Schema 3: `position before_char = 0, after_char = 1`.
Schema 3: `prevent_recursion` → `preventRecursion`.

---

## Sticky Values

| Value | Use case                                    |
|-------|---------------------------------------------|
| 0     | Default (non-event entries)                 |
| 3–5   | Brief events, passing encounters            |
| 5–8   | Combat, key conversations, active scenes    |
| 15+   | Permanent world-state changes               |

Do NOT also increase depth on sticky entries (double-persistence waste).

---

## Depth Overrides

- Layer 1 rules: global scan_depth + 1–2 (rules should never "fade")
- Layer 4 items/minor locations: global scan_depth - 1 (fade faster)
- Sticky entries: do NOT increase depth alongside sticky

---

## Large Cast Scaling (40+ Characters)

### Anchor Compression (8+ faction anchors)
- Trim prose to minimum: name, one-line purpose, roster, one rival
- Move history/politics to keyword-triggered Layer 4 detail entries
- Minor factions (1–2 members): merge into "Independent Operators" / "Minor Factions"
- 12+ factions: consider making minor anchors keyword-triggered (not constant)

### Character Entry Economy

All tiers include ALL fields (appearance, personality, history, home, relationships,
items/clothing, temporal context). Tiers control *depth and length*, not which fields
are present. **In Full Detail Mode, every character is Tier A** — tiers B and C do not
exist. Every character gets maximum depth and nuance regardless of narrative importance.

- Tier A (protagonist, major cast — or ALL characters in Full Detail): Full entries, maximum depth and nuance
- Tier B (recurring supporting): All fields present, moderate depth. 2–3 sentence
  appearance, 1 paragraph personality, concise history, key relationships.
- Tier C (background, one-scene NPCs): All fields present, concise. 2 sentence
  appearance, brief personality, 1–2 sentence history, notable items only.

### Splitting Across Multiple Lorebooks (60+ entries)
ST supports multiple active World Info books. Split options:
- Geographic: regional lorebooks + shared world rules
- Narrative arc: "Main Cast & Core Locations" + "Extended World" + shared rules
- Era: "Present Day" + "Historical" + shared constants

Output as separate Schema 3 files with setup note explaining dependencies.

---

## World State Block (Optional)

Generated when user requests "add world state."

```
[WORLD STATE — {World Name}]
Era/Period: {current era}
Dominant Power: {who holds power}
Active Conflicts: {1-3 lines}
Recent Events: {1-3 lines}
Public Mood: {atmosphere}
Season/Climate: {if relevant}
Wild Cards: {unstable elements, 1-2 lines}
```

Under 200 tokens, present tense, designed for manual user updates.
If baked in: constant Layer 1 entry, `position: before_char`, `insertion_order/order: 950+`.

---

## Non-Narrative Reference Worlds

For TTRPG systems, encyclopedias, world bibles without narrative arc.
Four-layer structure adapts:

- Layer 1 — SYSTEM RULES: Same. Core mechanics, constraints. RULE: prefix.
- Layer 2 — CATEGORY ANCHORS (replaces faction anchors): Organize by knowledge domain.
  "Character Classes," "Schools of Magic." Name everything in category for recursion.
- Layer 3 — DETAILED REFERENCE ENTRIES: Full reference articles. Clear informative writing
  replaces evocative prose. Mechanics, capabilities, interactions, edge cases.
- Layer 4 — SUB-ENTRIES: Individual spells, items, events, minor locations.
  `prevent_recursion: true` (leaf nodes).

"Prose over lists" relaxes for mechanical info (stats, abilities, costs).
Suggest reference approach when: no protagonist, no narrative arc, framed as
"reference for my D&D campaign" / "encyclopedia" / "system guide."
