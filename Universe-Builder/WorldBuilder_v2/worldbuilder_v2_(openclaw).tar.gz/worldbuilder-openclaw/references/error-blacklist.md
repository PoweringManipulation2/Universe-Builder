# Error Blacklist

Check every output against this list before presenting to user.

## Schema Errors

- ❌ Schema 2 (`character_book`) for an independent character card
- ❌ Embedded entries array format for standalone lorebook
- ❌ `"keys"` / `"secondary_keys"` in standalone (correct: `"key"` / `"keysecondary"`)
- ❌ `"insertion_order"` in standalone (correct: `"order"`)
- ❌ String position values in standalone (correct: integers `0` or `1`)
- ❌ `"enabled: false"` in standalone (correct: `"disable: true"`)
- ❌ `scenario` field in a world card (Schema 2)
- ❌ `scenario` in character card unless user explicitly requested it
- ❌ Duplicate `id`/`uid` values — always increment from 0
- ❌ Duplicate standalone entry object keys — sequential `"0"`, `"1"`, `"2"`...
- ❌ Omitting `"enabled": true` in embedded entries — disables on import
- ❌ Using `spec: "chara_card_v2"` — update to `"chara_card_v3"` with `spec_version: "3.0"`
- ❌ Missing V1 backfill fields at top level (name, description, personality, first_mes, mes_example)
- ❌ V1 backfill fields out of sync with `data.*` fields
- ❌ Missing `use_regex` field in V3 entries — required, default `false`
- ❌ Missing `group_only_greetings` in V3 cards — required, default empty array

## Architecture Errors

- ❌ Entire cast's appearance in card description — only protagonist there
- ❌ Single population index listing every character — use faction anchors
- ❌ `prevent_recursion: true` on faction anchors (Layer 2)
- ❌ `prevent_recursion: true` on character entries referencing others
- ❌ `prevent_recursion: true` on location entries
- ❌ Faction anchors that don't name their members
- ❌ Character entries that don't name locations/people they know
- ❌ `recursive_scanning: false` on the lorebook
- ❌ Orphan entries that nothing triggers and aren't constant

## Writing Errors

- ❌ "Hello, I am [Name]" first messages — open in-scene
- ❌ World `first_mes` placing user in a specific scenario
- ❌ `personality` field on world card holding character traits — tone only
- ❌ Personality as trait list rather than prose
- ❌ Major character appearance under 3 sentences
- ❌ Historical characters given appearance unless directly relevant
- ❌ Empty or minimal lorebook entry content

## Consistency Errors

- ❌ Shared primary motivation without narrative justification
- ❌ A references B as ally while B never mentions A
- ❌ Timeline contradictions between backstories and events
- ❌ Duplicate or confusingly similar names in same world
- ❌ Dead character described as alive in the build's time period
- ❌ Character placed in a location they haven't reached yet in timeline

## Group Chat Errors

- ❌ Relationship described differently in two playable characters' cards without
  narrative justification (e.g. A says "close allies," B says "bitter rivals")
- ❌ Playable character's card duplicates world-level info that belongs in shared lorebook
- ❌ Shared lorebook contains full character entry for a character with their own card
- ❌ Faction anchor doesn't name playable characters

## Prompt Placement Errors

- ❌ World lore placed in `system_prompt` instead of lorebook entries
- ❌ Style guide placed in `post_history_instructions` (too long, regenerated every turn)
- ❌ Instructions TO the AI placed in `creator_notes` (user-facing, not injected by default)
- ❌ `talkativeness` left at `"0.5"` for group chat characters without considering personality
- ❌ Missing Playability Guide in `creator_notes` for World Mode or Group Chat Mode cards
- ❌ Hardcoded scenario instead of leaving blank for user customization
- ❌ Playability Guide without available time periods (for builds that span multiple eras)
