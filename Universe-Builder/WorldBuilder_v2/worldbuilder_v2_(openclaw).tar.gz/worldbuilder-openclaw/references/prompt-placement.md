# Prompt Placement & SillyTavern Settings Guide

## Prompt Field Placement Strategy

SillyTavern has multiple fields that inject text into the prompt at different positions.
Understanding which field to use for what kind of instruction matters — the wrong
placement means the AI either ignores the instruction or treats it differently than
intended.

### The Fields and When to Use Them

**`system_prompt`** — Injected at the very top of the prompt, before everything else.

Use for: Hard behavioral rules the AI must always follow. Tone mandates, response format
constraints, absolute prohibitions. Think of this as the "prime directive" — it sets the
foundation before the AI sees anything about the character or world.

Examples: "Always write in third person past tense." "Never break character to address
the user directly." "Responses should be 2-4 paragraphs."

Don't use for: Character personality (that's `description`/`personality`), world lore
(that's the lorebook), or style guides (those go in `creator_notes` or as a lorebook
entry).

**`post_history_instructions`** — Injected after the conversation history, right before
the AI generates its response. Also called "UJB" (User Jailbreak) in some contexts.

Use for: Instructions that should be the last thing the AI "reads" before responding.
Reminders, reinforcements, and anything that benefits from being close to the generation
point. This position gives it strong influence because of recency bias in attention.

Examples: "Remember: {{char}} is hiding their true feelings." "This scene is tense —
keep dialogue clipped and body language guarded." "Do not repeat information already
established in the conversation."

Don't use for: World-building details (they'll be re-injected every message, wasting
tokens on static info). Long prose style guides (too much text here slows generation).

**`creator_notes`** — Displayed to the user in the character editor. Some frontends can
optionally inject this into the prompt, but its primary purpose is out-of-band
communication to the user.

Use for: The Playability Guide (time periods, playable roles, starting locations,
scenario examples, setup instructions). Instructions TO the person using the card.
"This card works best with Claude." "Set context to 8K minimum." "Import the companion
lorebook." Prose style guide placement notes.

Don't use for: Anything that MUST be in the prompt for every message — use
`system_prompt` or a constant lorebook entry for that. If a frontend doesn't inject
creator_notes, the AI never sees it, which is fine — it's for the human.

**Author's Note** (not a card field — user-configured in ST)

Use for: Lightweight, session-specific instructions. Prose style guides. Situational
nudges. The user sets this themselves, but cards can recommend Author's Note content
in `creator_notes`.

Position: Configurable by user (typically depth 0-4 from the end of history).

### Placement Decision Tree

What kind of instruction is it?

1. "The AI must always do/never do X" → `system_prompt`
2. "Remember X right before responding" → `post_history_instructions`
3. "Dear user, please configure X" → `creator_notes`
4. "Write in this prose style" → Constant lorebook entry (Layer 1, order 990) OR
   `system_prompt` if short. Recommend Author's Note placement in `creator_notes`.
5. "World rule: magic costs life force" → Lorebook Layer 1 constant entry
6. "Character always does X" → Bake it into the character's `description` or
   `personality` field, not a separate prompt field

### API/Model Considerations

Different APIs handle these fields differently:
- **Claude**: Strong adherence to system prompt. post_history_instructions effective.
- **OpenAI/GPT**: System prompt influence varies by model. post_history_instructions
  ("UJB") is often the strongest position.
- **Local models**: Highly variable. Some ignore system prompts entirely. Lorebook
  entries positioned close to the response (high insertion_order) are most reliable.

The safest strategy for maximum compatibility: put critical rules in BOTH `system_prompt`
AND as a constant lorebook entry. Redundant but reliable.

---

## Talkativeness

The `talkativeness` field controls how often the character speaks in group chats.
Range: `"0.0"` (rarely speaks unless addressed) to `"1.0"` (speaks on almost every turn).

**Guidance by character type:**
- Protagonist/narrator: `"0.8"` — should be active in most scenes
- Active supporting character: `"0.6"` — regular contributor but not dominant
- Quiet/reserved character: `"0.3"` — speaks when spoken to or when relevant
- Background NPC: `"0.1"` — rarely chimes in, only when directly relevant
- Default: `"0.5"` — moderate, used when no specific personality guidance applies

For Character Mode (single card, no group chat), talkativeness has no practical effect.
Set to `"0.5"` by default. For Group Chat Mode, set talkativeness per-character based
on their personality — a boisterous tavern keeper should be higher than a stoic guard.

Include talkativeness guidance in post-generation settings when building group chat cards.

---

## Context and Response Length Interaction

The lorebook's token budget interacts with the user's context window and response
length settings. A lorebook consuming 4096 tokens in an 8K context leaves only ~4K
for conversation history and the response — which can make the AI feel "forgetful"
because it can't see much conversation.

**Post-generation recommendations should include:**
- Minimum context size recommendation based on lorebook complexity
- Suggested token budget as a percentage of context (aim for 20-30%)
- Warning if constant entries alone consume >15% of expected context

| Lorebook size    | Minimum context recommendation |
|------------------|-------------------------------|
| Under 20 entries | 4K sufficient                 |
| 20-40 entries    | 8K recommended                |
| 40-60 entries    | 16K recommended               |
| 60+ entries      | 32K+ recommended              |
| Full Detail Mode | 16K minimum, 32K+ preferred   |

Include these recommendations in the STEP 9 post-generation settings output.
