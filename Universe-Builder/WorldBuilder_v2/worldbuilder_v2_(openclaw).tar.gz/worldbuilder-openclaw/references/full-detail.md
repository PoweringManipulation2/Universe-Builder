# Full Detail Mode

Activated by "full detail" or "insane detail." User explicitly doesn't care
about token economy — wants maximum completeness.

## The Core Principle

**Every character is Tier A.** There are no tiers in Full Detail Mode — no Tier B,
no Tier C. A background tavern keeper gets the same exhaustive Tier A treatment as the
protagonist. A minor crossroads gets the same sensory and cultural depth as the capital
city. The only difference is how much canonical information exists — write until the
information is genuinely exhausted, not until a word count is reached.

Every token range becomes a floor, not a ceiling. Every character entry uses the full
Tier A field list with maximum depth and nuance, regardless of the character's narrative
importance.

## Character Entries (Layer 3) — ALL Characters, No Exceptions

Every character — protagonist, side character, background NPC, historical figure —
gets the full treatment:

- **Appearance**: Exact build, posture, gait, scarring, hands, skin texture, how they
  carry themselves, resting expression, what's different when they're tense. Clothing
  state — not just "wears armor" but what kind, how worn, how fitted, what's customized.
- **Personality**: Who they are and WHY. Formative events that shaped them. Contradictions
  (kind but ruthless when threatened). Behavioral variation by audience — how they act
  with superiors vs. subordinates vs. strangers vs. children vs. people they desire.
- **History**: Full backstory. Where they came from, what happened to them, turning points,
  regrets, accomplishments. Even a background blacksmith has a story — where they
  apprenticed, why they settled here, what they lost along the way.
- **Home**: Where they live. What their space looks like, what it says about them.
  A character's home is a window into their psychology.
- **Relationships**: Texture of each dynamic, not just labels. Not "allies with Voss"
  but "trusts Voss with her life in battle but suspects Voss would sacrifice her for
  the mission without hesitation." Include relationships with places, factions, and ideas.
- **Items & Clothing**: Every significant possession. What they carry, why, what it means
  to them. Items they've lost that still matter.
- **Voice**: Full speech patterns. Example phrasings. What words they use, what words
  they'd never use. How they sound when angry vs. relaxed vs. lying.
- **Behavior**: Under pressure, in intimacy, in conflict, alone, caught lying, given
  authority, stripped of power, grieving, celebrating.
- **Secrets**: What they hide from others. What they don't know about themselves.
  Suspicions they harbor. Blind spots.
- **Temporal context**: Active period, current status (alive/dead/missing), current
  location, and how their role has changed over time.

## Faction Anchors (Layer 2)

- Founding history and origin myth (how members tell the story of their beginning)
- Hierarchy and power structure (formal and informal)
- Political stance and goals (stated and actual)
- Active operations and current priorities
- Rivalries with grievances (not just "rivals the Hollow Court" but WHY and since when)
- Resources, territory, strategic position
- **Culture and values** — What do members believe? What binds them beyond structure?
  What are their traditions, rituals, taboos? How do they greet each other? What's their
  attitude toward outsiders? What would a member die for? What would make a member leave?
- **Daily life** — What does an ordinary day look like for a rank-and-file member?
- **Internal tensions** — What do members disagree about?
- Still name every member. Accept higher constant token cost.

## Location Entries (Layer 4)

- Full sensory sweep: sound, smell, light quality, temperature, air quality, what feels
  wrong or right about this place
- History: who built it, what happened here, what it used to be
- Current state: who controls it, what condition it's in, recent events
- **Culture and atmosphere**: What is daily life like here? What do people who live here
  value? How do locals behave vs. visitors? What are the customs, the unspoken rules,
  the things everyone knows but nobody says? What kind of food is sold, what music is
  played, what stories are told?
- All NPCs by name (enables recursion)
- All items by name (enables recursion)
- Hazards, secrets, hidden areas
- Sensory shift by time of day (dawn vs. midnight)

## World Rules (Layer 1)

Every constraint with edge cases, exceptions, violation consequences.
What happens at the boundaries of the rule? Who has broken it? What loopholes exist?

## Card Fields

- `description`: 3–5 paragraphs. History, power dynamics, cultural texture, daily life.
- `first_mes` / `alternate_greetings`: Write to natural scene end. No length target.
  Establish atmosphere, NPC interaction or environmental detail.
- `mes_example`: 5–8 exchanges minimum. Full scene beats. Show range: combat, quiet
  conversation, caught off guard, social tension.
- `creator_notes`: The Playability Guide — comprehensive. Time periods with descriptions,
  all playable roles, starting locations with NPC encounters, scenario examples,
  writing style notes, model recommendations, and full setup instructions. The user
  should be able to start playing immediately from reading this field alone.

## Token Budget

Minimum: 4096. If constants alone exceed 2048, raise to 6144+.

## Batch Size

Reduce to ~5 entries per batch. Full Detail entries are substantially larger and need
more care for cross-referencing and consistency.

## Pre-Generation Checklist & Research-First Batch Loop

Full Detail Mode always uses the pre-generation checklist (including the recursion
structure map) and research-first batch loop described in SKILL.md under "Automated
Batch Generation Pipeline." These activate automatically for Full Detail builds
(regardless of entry count) and for any standard build with 30+ entries. In Full
Detail Mode, batch size is ~5 entries instead of ~10.

The recursion structure map is especially important in Full Detail Mode because every
character is Tier A — the entries are longer, contain more relationship references, and
create denser keyword chains. The post-generation audit (also in SKILL.md) validates
that all these chains fire correctly after generation completes.

## What Does NOT Change

- Schema structure
- Recursion architecture
- Inventory verification requirement
- Explicit confirmation requirement
- Automated batch pipeline (just with smaller batches)
- Temporal accuracy requirements (still mandatory)
