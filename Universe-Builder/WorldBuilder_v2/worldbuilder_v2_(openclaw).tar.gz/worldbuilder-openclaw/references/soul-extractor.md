# Soul Extractor Mode

Builds a reusable prose style guide capturing an author's voice so the AI
reproduces it in NEW scenes, locations, and situations — not just mimicking
established moments.

## The Problem It Solves

"Write like this" gives surface to copy but no understanding of WHY. When
scenes shift to unfamiliar territory, AI reverts to default voice. The Soul
Extractor gives it rules.

## Workflow

### STEP 1 — INTAKE

User pastes 500+ words ideally, from varied scenes (action, dialogue, quiet).
More variety = more robust guide.

- Under 300 words: warn extraction will be thin. Ask for more but proceed if unavailable.
- Author/book named without text: use training data knowledge. Flag that extraction is
  based on general knowledge, offer to refine with sample.

### STEP 2 — ANALYSIS

Extract these dimensions. Internalize for guide output — do NOT list findings to user.

- **SENTENCE ARCHITECTURE**: Average length, structure tendencies, rhythm variation,
  paragraph length and transitions.
- **VOCABULARY & REGISTER**: Formal/informal/archaic/modern/technical/poetic/sparse.
  Recurring word families. Words clearly avoided.
- **SENSORY PRIORITIES**: Which senses dominate, introduction order in new spaces.
  Environment-first vs. character-reaction-first.
- **DIALOGUE STYLE**: Tagging approach, internal thought interruption, exposition handling,
  dialogue-to-narration ratio.
- **EMOTIONAL TEXTURE**: Conveyance channel (action, internal monologue, physical sensation,
  environmental mirroring, subtext). What the author does NOT do.
- **POV & NARRATIVE DISTANCE**: POV type, camera closeness, distance shifts, narrator
  personality or invisibility.
- **TONAL SIGNATURE**: Overall feel. How tonal shifts are handled.
- **SCENE CONSTRUCTION**: How scenes open, close, and transition.

### STEP 3 — GUIDE OUTPUT

Output structured PRESCRIPTIVE style guide (not descriptive):

- ❌ "The author uses short sentences and favors tactile imagery."
- ✅ "Keep sentences under 15 words during tension. Over 25 only in reflective pauses.
  Lead with touch/feel before visual in new spaces."

### Format

```
── PROSE STYLE GUIDE: [Author Name / Source Title] ──

SENTENCE RULES       [3–5 prescriptive rules]
VOCABULARY RULES     [3–5 rules]
SENSORY RULES        [2–4 rules]
DIALOGUE RULES       [3–5 rules]
EMOTION RULES        [2–4 rules]
SCENE RULES          [3–5 rules]
POV RULES            [2–3 rules]
NEGATIVE RULES       [3–5 explicit prohibitions — often most valuable]

── END STYLE GUIDE ──
```

Token target: 400–800. Dense enough to be useful, short enough for
Author's Note / creator_notes.

Full Detail Mode: No ceiling. Expand every section with sub-rules,
edge cases, and example phrasings written in the target style (NOT
quoted from source).

## Integration with Other Modes

- **With Character Mode**: Paste into `creator_notes` or `system_prompt`.
- **With World Mode**: Paste into world card's `creator_notes` or `system_prompt`.
  Strongest use case — maintains voice in new locations/characters.
- **As constant lorebook entry**: Layer 1, `position: before_char`,
  `insertion_order/order: 990`. `comment: "STYLE GUIDE — [Author/Source]"`.
- **As Author's Note**: Paste directly. Lightest-weight option.

Ask user where they plan to use it and format accordingly.

## Refinement Commands

- **"Test it"** → 150–250 token sample scene in extracted style. Set in
  location/situation NOT in original sample. Ask if it feels right.
- **"More [sensory/dialogue/emotion]"** → Expand specified section.
- **"Less [formal/poetic/sparse]"** → Adjust rules, note what changed.
- **"Combine with [another author]"** → Extract new sample, merge guides.
  Flag conflicts, ask which to prioritize or propose hybrid rules.
- **"Make it a lorebook entry"** / **"for Author's Note"** → Reformat for
  specified placement without changing rules.

## No Batching Needed

Soul Extractor produces a text style guide. No phased generation needed.
