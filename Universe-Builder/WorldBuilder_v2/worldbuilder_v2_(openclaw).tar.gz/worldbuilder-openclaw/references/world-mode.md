# World Mode

Builds a full world card (Schema 2) as narrator, with embedded lorebook
mapping cast and universe.

## Card Field Reference

| Field                 | Content                                                    | Tokens    |
|-----------------------|------------------------------------------------------------|-----------|
| `name`                | World/setting title                                        | —         |
| `description`         | World primer (1–2 paragraphs) + protagonist appearance ONLY. Keep lean — always loaded. | Variable |
| `personality`         | World tone only — genre, emotional temperature, themes. NEVER character traits. | 80–150 |
| `first_mes`           | Atmospheric narrator hook — texture, not scenario. No "you are in X." | 150–300 |
| `alternate_greetings` | 2–3 different entry points: era, location, social position | 150–300 each |
| `mes_example`         | Sample narrator/NPC exchanges                              | 200–400   |
| `creator_notes`       | Structured AI rules. One per line, action-first.           | 150–250   |

## Critical Architecture Rule

`description` holds TWO things only:
1. World primer (1–2 paragraphs)
2. Protagonist's appearance (if central character exists)

ALL other content (characters, locations, factions, items, rules) lives in the lorebook.

## Personality Field

Tone descriptors only:
- ✅ "gothic horror, slow dread, human cost over spectacle"
- ❌ Character traits, personality descriptions

## first_mes Rules

- Open with atmosphere and texture
- Never place user in a specific scenario ("You are in the tavern...")
- The narrator SETS a scene, it doesn't assign one
- `{{char}}` is the narrator voice in World Mode

## mes_example Format

```
<START>
{{user}}: [User action]
{{char}}: [Narrator response — world reacts to user]

<START>
{{user}}: [Different context]
{{char}}: [Different narrator response showing range]
```

Show range: combat narration, quiet moments, environmental description, NPC dialogue.

## Lorebook Architecture

World Mode uses Schema 2 (embedded lorebook). Read `references/lorebook-architecture.md`
for the four-layer recursive tree system, keyword rules, and insertion order tiers.

Read `references/schemas.md` for Schema 2 structure before generating.

## Batch Generation

World Mode builds use the automated batch pipeline from SKILL.md.
The card shell + constants go in Phase 1. Character and location entries
follow in subsequent phases of ~10 entries each.

## scenario Field

Do NOT include `scenario` in World Mode. It is stripped entirely from Schema 2.
