# Group Chat Mode — Multi-Card + Shared Lorebook

Builds multiple independent character cards (Schema 1) plus a standalone
lorebook (Schema 3) shared across all cards in a SillyTavern group chat.

## When to Use

- Multiple character cards coexisting in one world
- User says "group chat" or "multi-card"
- Cards need to be mix-and-matched across sessions

Do NOT use when: single world card with embedded characters (→ World Mode),
single character in isolation (→ Character Mode).

## Architecture — The Split

### Character Cards (Schema 1)
ONLY character-unique content: description, personality, first_mes,
alternate_greetings, mes_example, creator_notes. No `character_book`.
No world context baked in. Cards must work standalone — coherent without
lorebook, just missing world context.

### Shared Lorebook (Schema 3)
Everything about the WORLD not specific to one character's identity:
- Layer 1: World rules
- Layer 2: Faction anchors (naming ALL characters including playables)
- Layer 3: NPC entries for characters WITHOUT their own card
- Layer 4: Locations, items, faction details, events, concepts

Does NOT duplicate character card content. If "Commander Voss" has
her own card, no separate Layer 3 with her full appearance — faction
anchor names her for recursion, card handles the rest.

### Decision Rule
"Does this info change depending on which character is speaking?"
- Yes → character card
- No → shared lorebook

Relationships between playable characters: each card describes it FROM
THEIR PERSPECTIVE. Lorebook doesn't store these separately.

**Relationship cross-check (mandatory for group chat builds):**
After generating all character cards, run a relationship reciprocation audit:
1. For each playable character, extract every relationship mentioned in their card
2. Check that the OTHER character's card reciprocates — if Card A says "trusts Rhel
   with her life," Card B (Rhel) must mention Voss and describe the relationship
   from Rhel's perspective
3. Verify relationship TONE is consistent — if A says "bitter rivals," B shouldn't
   say "close allies" unless there's a narrative reason (unreliable narrator, one-sided
   grudge, etc.)
4. Flag asymmetries and fix them before presenting cards to user

This catches the most common group chat bug: two cards describing the same relationship
with contradictory details because they were generated in different batches.

Relationships with NPCs: card mentions NPC by name (enables recursion),
NPC's lorebook entry carries full detail.

## Faction Anchors with Playable Characters

Anchors name ALL members including those with their own cards.
Since playable characters load via their cards, anchor uses brief role tag:

```
"The Iron Vanguard — military faction, enforces order in the outer
districts. Members: Commander Sera Voss (playable), Lieutenant
Davan Rhel (playable), Archivist Nuno Cael, Recruit Maren Thay.
Rivals the Hollow Court. Controls the eastern gate."
```

"(playable)" is a user reference note, no mechanical effect.

## Keyword Considerations

Multiple characters generating messages = more names in scan window =
higher trigger frequency.

- `scan_depth` may need to be 1 lower than Dynamic Sizing recommendation
- Playable character names appear constantly (every message). If a name
  is a keyword on a lorebook entry, it fires frequently. Gate large
  entries behind secondary keys for more specific context.

## Output Format

Output order:
1. Character cards (Schema 1), each labeled:
   `── CHARACTER CARD 1: [Name] ──`
2. Shared lorebook (Schema 3), labeled:
   `── SHARED LOREBOOK: [World Name] (import via World Info panel) ──`
3. Post-generation settings (STEP 7)
4. Setup instructions:

```
⚙️ GROUP CHAT SETUP
─────────────────────────────────────
1. Import each character card as a separate character
2. Import the shared lorebook via World Info panel
3. Create a new group chat and add desired character cards
4. Ensure [World Name] is active in World Info panel
5. Characters share world context automatically
Lorebook works independently of which cards are loaded.
─────────────────────────────────────
```

## Batch Generation

Group Chat Mode produces multiple files. The batch pipeline handles:
- Character cards: usually 1 per phase (or batched if simple)
- Shared lorebook: uses standard ~10 entry batch pipeline
- All files written to disk separately, all presented to user as downloads
