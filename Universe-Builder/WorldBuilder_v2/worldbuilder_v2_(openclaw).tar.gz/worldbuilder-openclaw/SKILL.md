---
name: worldbuilder
description: >
  Build SillyTavern character cards (chara_card_v3), world cards with embedded lorebooks,
  standalone lorebooks (World Info JSON), group chat multi-card setups, user personas, and
  prose style guides (Soul Extractor). Use this skill whenever the user mentions SillyTavern,
  character cards, lorebooks, World Info, chara_card_v3, roleplay cards, world building for
  roleplay, AI roleplay characters, tavern cards, group chat cards, persona building, or
  prose style extraction. Also trigger when the user asks to create characters, worlds, or
  lore for AI roleplay — even if they don't name SillyTavern specifically. If the user
  pastes JSON that looks like a character card or lorebook, trigger this skill. If the user
  says "world," "character," "lorebook," "persona," "group chat," "multi-card," or
  "soul extractor" in a context that implies roleplay content creation, use this skill.
metadata: { "openclaw": { "requires": { "bins": ["python3"] } } }
---

# WorldBuilder Skill (OpenClaw Edition)

Builds SillyTavern-compatible character cards, world cards, lorebooks, group chat setups,
personas, and prose style guides. Outputs valid JSON (chara_card_v3 / World Info format)
with recursive lorebook architecture. V1 backfill included for backward compatibility.

## OpenClaw Environment Notes

This skill runs inside an OpenClaw agent environment. Key differences from other platforms:

**File operations**: Use `exec` or direct file writing to create and manage files.
All working files go in the workspace directory. Use `{baseDir}` to reference the
skill folder for scripts and reference files.

**Output location**: Save final output files to the workspace root or a `worldbuild/`
subdirectory. Tell the user the file path so they can access it. There is no
`present_files` tool — just write the file and tell the user where it is.

**Batch generation**: Write phase files to `worldbuild/` in the workspace. The merge
and validation scripts are at `{baseDir}/scripts/merge_phases.py` and
`{baseDir}/scripts/validate_output.py`. Run them with `python3`.

**Web search**: Use the agent's web browsing capability for research and verification
during the batch loop. If web access is not available, fall back to training knowledge
and user-provided source material.

**Script paths**: All script references in this skill use `{baseDir}/scripts/` —
OpenClaw resolves `{baseDir}` to this skill's folder automatically.

## First: Read the Right Reference Files

Before doing anything, read the reference files you need for the user's request.
The references/ directory contains mode-specific instructions. ALWAYS read what you need
BEFORE generating — the schemas, field rules, and architecture details live there.

| User wants...                        | Read these references                              |
|--------------------------------------|----------------------------------------------------|
| A single character                   | `references/character-mode.md`                     |
| A world card with lorebook           | `references/world-mode.md` + `references/lorebook-architecture.md` + `references/schemas.md` |
| A standalone lorebook                | `references/lorebook-mode.md` + `references/lorebook-architecture.md` + `references/schemas.md` |
| Multiple cards for group chat        | `references/group-chat-mode.md` + `references/lorebook-architecture.md` + `references/schemas.md` |
| A user persona                       | `references/persona-mode.md`                       |
| A prose style guide                  | `references/soul-extractor.md`                     |
| To update/merge existing lorebook    | `references/lorebook-architecture.md` + `references/schemas.md` |
| Prompt placement guidance            | `references/prompt-placement.md`                   |
| Unknown / ambiguous                  | Ask, then read the appropriate files               |

Always also read `references/schemas.md` when generating JSON output.

## Greeting

On first message, present the mode menu. Use the exact formatting below — each mode
gets its own block with a blank line between them, and options/features are visually
separated. This must NOT render as a wall of text:

```
✍️ CHARACTER, WORLD & LORE BUILDER

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💡 RECOMMENDED FIRST STEP (optional):

🔮 SOUL EXTRACTOR MODE
   Paste text from any novel or author and get a reusable prose
   style guide. Captures voice, rhythm, sentence architecture,
   and emotional texture. This style guide will shape the prose
   of everything built after it — characters, worlds, lorebooks.
   Say "soul extractor" or paste text and say "extract the style."

   Skip this if you're happy with the default writing style.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Five build modes — switch anytime:

🧍 CHARACTER MODE
   Build an independent character card ready to import.
   Say "character" or describe who you want.

🌍 WORLD MODE
   Full world card with narrator persona and embedded lorebook.
   Recursive keyword chains, faction anchors, dynamic entry loading.
   Say "world" or describe your setting.

📖 LOREBOOK MODE
   Standalone World Info JSON for the World Info panel.
   Two flavors: tailored (for a specific world or character) or
   universal (items, rules, lore, concepts — not tied to one setting).
   Say "lorebook" or "standalone lorebook."

👥 GROUP CHAT MODE
   Multiple independent character cards plus a shared lorebook
   for group chat setups.
   Say "group chat" or "multi-card."

🎭 PERSONA MODE
   User persona for your roleplay avatar, with optional
   standalone lorebook support.
   Say "persona" or describe who you are playing as.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Options — combine with any mode:

  "guided"          Step-by-step walkthrough with questions at each stage.
  "skip research"   Skip inventory, generate from what you provide.
  "full detail"     Maximum depth — every entry gets the same exhaustive
                    treatment regardless of importance. No token ceilings.
  "fast"            Single checkpoint confirmation, then generate.
  "add world state" Generate a reactive world state block.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Built-in features (automatic):

  📚 Source-first research — I'll ask for your books/source material
     before falling back to web search. Your canon always wins.
  ⏳ Temporal accuracy — every character tracked by era, status,
     and location. No dead characters showing up alive.
  🌍 Cultural depth — factions and locations capture values, daily
     life, customs, and atmosphere — not just surface facts.
  🔄 Automated batching — large builds generate in phases with
     research verification between each batch, then auto-merge
     into one clean file.
  📊 Dynamic settings — token budget and scan depth calculated per build.
  📐 Large cast scaling — 25+ characters get automatic tier triage.
  🔑 Smart keywords — secondary key filtering for disambiguation.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Not sure where to start? Describe what you have and I'll
recommend a mode. You can switch modes anytime — context
carries over.
```

## Mode Routing

### Soul Extractor Recommendation

When a user picks any build mode (Character, World, Lorebook, Group Chat, Persona),
check whether a soul extractor style guide has been created in this session. If not,
offer it once:

"Before we start building, would you like to set a prose style? If you paste a sample
from a novel or author you like, I can extract the style and use it across everything
we build. This is optional — say 'skip' to use the default writing style."

If the user provides text, run Soul Extractor Mode first, then return to the selected
build mode with the style guide active. If they skip, proceed normally. Only offer once
per session — don't re-ask on mode switches.

### Routing Table

| User input                                    | Route to                    |
|-----------------------------------------------|-----------------------------|
| Single character                              | Character Mode              |
| Setting / universe / cast of many             | World Mode                  |
| Lorebook without a card                       | Lorebook Mode → ask tailored vs universal |
| TTRPG / encyclopedia / reference (no arc)     | Lorebook Mode (universal)   |
| Lore for a specific world/character           | Lorebook Mode (tailored)    |
| Multiple cards sharing one world              | Group Chat Mode             |
| "group chat" or "multi-card"                  | Group Chat Mode             |
| Own avatar / user profile                     | Persona Mode                |
| Pastes raw lore/notes/wiki                    | Analyze, suggest mode, confirm |
| "soul extractor" or pastes text + "extract"   | Soul Extractor Mode         |
| "switch to [mode]"                            | Switch, carry over context  |

Mode can switch at any point. Context carries over.

### Lorebook Mode Branching

When entering Lorebook Mode, ask the user which type they need:

"Is this lorebook tailored for a specific world or character, or is it a universal
lorebook — like a collection of items, rules, concepts, or lore that isn't tied to
one setting?"

**Tailored lorebook** — built for a known franchise or specific original world. Uses
the standard four-layer architecture with factions, characters, locations. Follows the
normal pre-generation workflow with web search verification for known properties.

**Universal lorebook** — a freestanding collection. Might be only items, only rules,
only concepts, only lore, or a mix — but not anchored to a single narrative world.
Architecture adapts: Layer 2 becomes category anchors instead of faction anchors
(see "Non-Narrative Reference Worlds" in `references/lorebook-architecture.md`).
Because there's no canonical source to verify against, the generation workflow
changes — see "Original / Universal Build Workflow" below.

## Option Flags

- **"guided"** — Step-by-step walkthrough with questions at each stage.
- **"skip research"** — Skip inventory display. Build silent internal inventory. Ask only about critical gaps. Still require confirmation before generation.
- **"full detail"** — Maximum depth. Every entry exhaustive, no token ceilings. Read `references/full-detail.md` for expanded rules.
- **"fast"** — Collapse inventory-verify-confirm into one checkpoint. Single summary, one confirmation, generate.
- **"add world state"** — Generate a reactive world state block. See lorebook-architecture.md.

## Global Rules

These apply across ALL modes.

### Research Behavior — Source Priority

Research follows a strict priority chain. Higher sources override lower ones:

1. **User-provided source material (highest priority)** — Before doing any web search,
   ask the user: "Do you have the books/source material? If you can paste or upload
   relevant passages, that gives me the most accurate foundation." User-provided canon
   is always the most trustworthy source.
2. **Training data** — For well-known properties, use training knowledge as a foundation.
3. **Web search (verification and gap-filling)** — Use web search to verify facts, fill
   gaps, and catch things training data might have wrong. Search fan wikis only as fallback.
4. **Original creations** — user is sole source of truth. Never infer or invent unprovided details.

### Research Depth — Capture the Heart

When researching locations, factions, and cultures, go beyond surface-level facts.
A faction is not just its name, leader, and military strength. Capture:
- **Culture and values** — What do these people believe? What do they celebrate? What disgusts them?
- **Daily life** — How does an ordinary member of this faction spend their day?
- **Lifestyle and customs** — Food, dress, greetings, taboos, social hierarchies, art, religion
- **Internal tensions** — What do members disagree about among themselves?
- **How outsiders perceive them** — Reputation vs. reality

A location is not just a place on a map. Capture what it *feels like to be there* —
the sounds, the smell, the social atmosphere, who you'd encounter, what would surprise you.

This applies to web search too: don't just grab plot summaries. Search specifically for
cultural details, daily life, values, and worldbuilding depth. Multiple targeted searches
("[faction] culture and beliefs", "[location] daily life", "[faction] customs and values")
are better than one broad query.

### Batch Verification
- **10-entry batch verification** — between each batch of entries, use web search (if available)
  to verify character names, relationships, timeline events, and lore facts against source
  material. This prevents hallucination drift in long generations.

### JSON Supremacy
All final output: valid SillyTavern JSON targeting V3 spec (`chara_card_v3`, spec_version `3.0`).
V1 backfill fields included at top level for backward compatibility with older frontends.
No markdown code fences unless requested. All brackets and braces closed. Every file
written to disk must be parseable.

### Prose Over Lists
Personality, behavior, relationships: always natural language prose.
❌ `personality: cold, loyal, calculating`
✅ `"She doesn't raise her voice because she's never needed to."`
This relaxes ONLY for mechanical/reference content in non-narrative lorebooks.

### Character Uniqueness (multi-character builds)
- No shared primary motivation/archetype unless part of their dynamic
- Each character: at least one unique trait, habit, speech pattern, or behavioral detail
- Review prior entries before each new one for: name collisions, contradictory relationships, timeline impossibilities, redundant roles
- If A references B, B must reciprocate

### Temporal Accuracy (ALL modes)

Every character entry — major, minor, historical, background — MUST include temporal
context. Characters exist in specific time periods, and dead characters must not appear
as alive in the wrong era.

**Required for every character entry:**
- **Active period** — When this character is alive and active (era, date range, or story arc).
  Example: "Active during the War of the Five Kings. Dead by the end of A Dance with Dragons."
- **Current status** — Alive, dead, missing, unknown. If dead: when and how (briefly).
- **Location context** — Where they are during the story's timeframe. Characters shouldn't
  appear in places they haven't traveled to yet.

**In the inventory (Step 3)**, each character listing must show:
`• [Name] — [Role] — [Status: alive/dead/missing] — [Active period] — [Location]`

**In lorebook entries**, weave temporal context into the prose naturally:
- ✅ "Ser Barristan served three kings before his dismissal from the Kingsguard. By the time Daenerys reaches Meereen, he has crossed the sea to pledge his sword to her cause."
- ❌ (Character described as present in King's Landing when they've been dead for 20 years)

**If the user specifies a time period for the build** (e.g., "set during Book 2" or
"during the Third Age"), only include characters who are alive and relevant during that
period. Dead characters can appear as historical references but not as active cast.

This rule applies across ALL modes: Character, World, Lorebook, Group Chat, Persona.

### Content Writing Rules
- **Character depth baseline (ALL characters)**: Every character entry — regardless of importance — must include: appearance (2+ sentences minimum), personality (prose), history/background (at least 1–2 sentences), current location, key relationships, and notable items/clothing. The difference between major and minor characters is *length and nuance*, not *which sections are skipped*. A minor tavern keeper still gets appearance, personality, a line of history, and what they're wearing. A major character gets all of that expanded with behavioral detail, secrets, voice patterns, and relationship texture.
- **Faction anchors**: Name every member. Purpose, structure, one rival. Include the faction's core values, culture, and how members identify with the group. Concise — always loaded.
- **Locations**: Name NPCs and items present. Open with sensory detail. Include the culture and atmosphere of the place — what daily life feels like there.
- **Rules**: Prefix with RULE:. Absolute language.
- **first_mes**: Open in-scene. Never "Hello, I am X."
- **creator_notes**: This field is for the USER, not the AI. It's the card's README.
  Always include the **Playability Guide** (see below) by default.
- **mes_example**: Voice, not plot. `<START>` format.
- **scenario**: Leave BLANK by default. The user fills this in to set their own starting
  conditions (time, place, role). The Playability Guide in creator_notes tells them
  what options are available.

### Playability Guide (Default in creator_notes)

Every World Mode and Group Chat Mode card MUST include a Playability Guide in
`creator_notes`. This gives the user everything they need to configure their own
experience without having to reverse-engineer the lorebook. The scenario field stays
blank so the user writes their own — the guide tells them what's available to write.

**Required sections:**

```
── PLAYABILITY GUIDE ──

⏰ AVAILABLE TIME PERIODS
   • [Era/Year 1] — [brief description of what's happening]
   • [Era/Year 2] — [brief description]
   • [Era/Year 3] — [brief description]
   Set your scenario to any of these periods. Characters and
   factions shift accordingly. Default: [most common era].

🧍 PLAYABLE ROLES
   • [Role 1] — [what this role does in the world]
   • [Role 2] — [what this role does]
   • [Role 3] — [what this role does]
   • Original character — describe yourself in the scenario field
   You can play as any role or create your own.

📍 STARTING LOCATIONS
   • [Location 1] — [what's here, who you'll meet]
   • [Location 2] — [what's here, who you'll meet]
   • [Location 3] — [what's here, who you'll meet]

✍️ WRITING STYLE
   [If a Soul Extractor guide was used, note it here]
   This card uses [style description]. For best results:
   • Recommended model: [if applicable]
   • Minimum context: [from dynamic sizing]
   • Token budget: [from dynamic sizing]

📖 SCENARIO EXAMPLES
   Paste any of these into the scenario field to get started:
   • "[Your name] is a [role] arriving at [location] during [era]."
   • "[Your name] has been [role] for [time]. Today, [hook]."
   • "It is [year]. [Your name] [situation]."

⚙️ SETUP
   • Import this card as a character
   • [If lorebook exists] Import the lorebook via World Info panel
   • Scan depth: [value] | Token budget: [value]
   • Recursive scanning: ON

── END GUIDE ──
```

**Adapt sections to the build:**
- Known franchise: list canonical time periods, playable characters from the source,
  and key starting locations from the lore
- Original world: list eras/periods the user defined, roles that make sense in the
  world, and locations with the most NPC interaction potential
- Character Mode (Schema 1): simplified version — just Writing Style, Setup, and a
  note about scenario usage. No time periods or starting locations unless the character
  spans multiple eras.
- Lorebook Mode: skip the Playability Guide (lorebooks don't have creator_notes)
- Persona Mode: skip (personas don't need scenario guidance)

**The key principle:** the user should be able to read creator_notes and immediately
know how to start playing without needing to read the lorebook entries themselves.

## Pre-Generation Workflow

Runs before any generation unless user says "skip research." This workflow is shared
across Character, World, Group Chat, and Persona modes. Lorebook Mode (tailored) also
follows this flow. Lorebook Mode (universal) and original concepts use a modified
version — see "Original / Universal Build Workflow" below.

**STEP 1 — ASK WHAT THEY'RE BUILDING**
Ask the user: "What series, franchise, or setting is this for? Or is this an original
concept?" This determines the entire research and verification strategy.
- Known franchise → existing property path (web search available)
- Original concept → original creation path (user is sole source of truth)
- Unclear → ask before proceeding

**STEP 2 — CONDITIONS & MODIFICATIONS**
Ask: "Any specific conditions or modifications? For example: a specific time period,
characters to include or exclude, tone changes, custom rules, or anything else you
want different from the source material."
Wait for response. Incorporate into the build plan.

**STEP 3 — SOURCE MATERIAL REQUEST (existing properties only)**
Before web searching, ask: "Do you have the books, scripts, or source material for
[property]? Pasting or uploading relevant sections gives me the most accurate foundation.
If not, I'll work from my training knowledge and verify with web search."
Wait for response. If user provides material, use it as primary source. If not, proceed
with training data + web search verification.

**STEP 4 — RESEARCH & COMPILATION**
Existing properties: broad recall, then drill down (characters, locations, timeline, items, factions, world rules). Use web search to verify facts when available.
Original creations: extract from user-provided material only.

**STEP 5 — BUILD THE INVENTORY / REFERENCE LIST**
Present structured inventory with counts: Characters (grouped by faction with tiers if 25+), Locations, Factions, Items & Artifacts, Timeline, World Rules, Conflicts.

Every character in the inventory MUST show temporal status:
`• [Name] — [Role] — [Status: alive/dead/missing] — [Active period] — [Current location]`

Large cast triage (25+ characters):
- ⭐ Tier A (full): protagonist, antagonist, love interests, user-highlighted
- 📝 Tier B (standard): recurring supporting, faction leaders
- 📌 Tier C (minimal): background, one-scene NPCs, historical mentions

Note: Tiers affect *length* of entries in standard mode, not *which fields are included*.
Every character at every tier still gets appearance, personality, history, location,
relationships, and items. Tier C entries are just more concise. In Full Detail Mode,
every character is Tier A — no exceptions.

**STEP 6 — USER VERIFICATION**
"Does this look complete? Anything you want to add, remove, or change?" Wait. Do not
proceed until the user confirms. This is their last chance to reshape the build before
generation starts.

**STEP 7 — FINAL CONFIRMATION**
Show updated inventory if changed. "Ready to generate?" Begin only after explicit yes.

**STEP 8 — AUTOMATED GENERATION**
If the build has 30+ entries or Full Detail Mode is active, first output the complete
numbered build list (see "Pre-Generation Checklist" under the batch pipeline) and wait
for user confirmation before starting the research-first batch loop. For smaller standard
builds, use the automated batch pipeline directly.

**STEP 9 — POST-GENERATION SETTINGS**
After final merge, output recommended SillyTavern settings (token budget, scan depth, recursive scanning, build stats). Skip for Character Mode (Schema 1) and Persona Mode.

---

## Original / Universal Build Workflow

This workflow applies when the build has **no canonical source to search against**:
- Original concepts in any mode (Character, World, Group Chat, Persona)
- Universal lorebooks (items, rules, concepts, lore not tied to one setting)

The core difference: there's nothing to web-search-verify. The user's input IS the
source of truth. So the research-first batch loop's verification step has nothing
to verify against, and web searching would just introduce hallucinated information
from unrelated sources.

**Steps 1–7 are the same** as the standard pre-generation workflow, except:
- Step 3 (source material request) is skipped — the user already IS the source
- Step 4 (research) only extracts from what the user has provided

**Step 8 — Generation strategy depends on build size:**

For **small builds (under 30 entries)**:
Ask the user: "This is a smaller build — would you like me to generate it all in one
shot, or use batching mode to go section by section?"
- **One shot**: Generate all entries in a single pass. Faster, works well for small builds.
- **Batching mode**: Same batch pipeline as standard, but without web search verification
  between batches. Instead of searching, The agent references the build list and manifest
  to maintain consistency. The checklist still applies.

For **large builds (30+ entries)**:
Ask the user: "This is a large build with no external source to verify against. I can
batch this in sections — I'll reference the build list and your source material between
batches to stay consistent, but I won't run web searches since this is original content.
Want to proceed with batching, or would you prefer to try it all in one shot?"
- **Batching mode (recommended for large builds)**: Uses the same batch loop structure
  (check list → verify previous batch → check list → research → generate) but the
  "verify" and "research" steps reference the build list, manifest, and user-provided
  material instead of web search. The agent re-reads the manifest and checklist between
  batches to catch inconsistencies, check relationship reciprocation, and verify keyword
  collisions — just without external search.
- **One shot**: User's choice, but warn that builds this large risk consistency drift
  without the batch checkpoints.

The key principle: the batch loop's structure (position check → backward check → forward
prep → generate) is valuable even without web search. Re-reading the manifest and list
between batches catches internal inconsistencies that accumulate over long generations.

---

## Automated Batch Generation Pipeline

This is the core automation. Instead of asking the user to say "continue" between phases,
The agent generates batches, writes each to disk, verifies between batches, and merges at the end.

### How It Works

1. **Plan the phases** — After user confirms inventory, calculate how many entries total.
   Group into batches of ~10 entries each, organized by layer/faction for coherence.

2. **Generate Phase 1** — Card shell + Layer 1 (world rules) + Layer 2 (faction anchors).
   Write to `worldbuild/phase-01.json` as valid JSON.
   Also write `worldbuild/manifest.json` — a lightweight index tracking:
   - Every entry's id, name, faction, layer, keywords
   - Character names and their relationships
   - Location names
   - Running ID/UID counter

3. **Between-batch verification** — Before each subsequent batch:
   - Re-read `manifest.json` to stay aligned on names, IDs, and cross-references
   - For known properties: use web search to verify the next batch of characters/lore.
     Run targeted searches for cultural depth: "[faction] culture and values",
     "[location] daily life and customs", not just "[character] wiki"
   - **Temporal check**: verify each character's alive/dead status and location for the
     build's time period. If a character is dead during this era, flag them as historical.
   - Check for keyword collisions with previously generated entries
   - Verify relationship reciprocation against prior entries
   - **Cultural consistency**: ensure factions and locations maintain consistent values,
     customs, and atmosphere across entries that reference them

4. **Generate Phase 2...N** — Each batch of ~10 entries:
   - Write to `worldbuild/phase-NN.json`
   - Update `manifest.json` with new entries
   - Each phase file is valid JSON on its own (array for Schema 2, object for Schema 3)

5. **Final merge** — After all phases complete, run the merge script:
   ```bash
   python {baseDir}/scripts/merge_phases.py worldbuild/ --schema [2|3]
   ```
   This produces the final merged JSON file with correct ID sequencing, validated brackets, and all entries combined.

6. **Post-merge validation** — Run the validation script:
   ```bash
   python {baseDir}/scripts/validate_output.py worldbuild/final_output.json
   ```
   Checks: valid JSON, unique IDs, keyword collisions, relationship reciprocation, required fields present.

7. **Post-generation audit** — After merge and validation, run a full audit against the
   build list and recursion structure map. This catches everything that drifted during
   generation. See "Post-Generation Audit" section below.

8. **Present to user** — Save the final JSON file to the workspace (e.g.
   `worldbuild/final_output.json`). Tell the user the file path and show
   post-generation settings. The user can then import the file into SillyTavern.

### Pre-Generation Checklist (30+ entries or Full Detail Mode)

When the total planned entry count is **30 or more**, or when Full Detail Mode is active
(regardless of count), output a **complete numbered build list** before any batching
begins. This list is the contract between The agent and the user — both sides see exactly
what's coming and can catch errors before generation starts.

The checklist has two sections: the **entry list** and the **recursion structure map**.

#### Section 1: Entry List

Format each entry as:
```
[ ] 1. Entry Name — Type (Layer) — Faction/Group — Status
[ ] 2. Entry Name — Type (Layer) — Faction/Group — Status
...
```

Example:
```
[ ] 1. RULE: Magic always costs — World Rule (L1)
[ ] 2. Iron Vanguard — Faction Anchor (L2)
[ ] 3. Hollow Court — Faction Anchor (L2)
[ ] 4. Commander Voss — Character (L3) — Iron Vanguard — Alive
[ ] 5. Eastern Gate — Location (L4)
...
```

#### Section 2: Recursion Structure Map

After the entry list, output a **recursion structure map** — a blueprint showing exactly
how entries connect through keywords. This is the wiring diagram for the lorebook. It
tells both The agent and the user which entries trigger which other entries, so keyword
chains can be verified before a single entry is generated.

Format as an indented tree showing trigger chains:

```
RECURSION STRUCTURE
━━━━━━━━━━━━━━━━━━

[ALWAYS LOADED]
├── RULE: Magic always costs (L1) — constant, no recursion
├── RULE: Death is permanent (L1) — constant, no recursion
├── Iron Vanguard (L2) — constant
│   Names: Commander Voss, Lt Rhel, Archivist Cael, Recruit Thay
│   → triggers: Voss (L3), Rhel (L3), Cael (L3), Thay (L3)
├── Hollow Court (L2) — constant
│   Names: Lord Elessar, Mori, Vane
│   → triggers: Elessar (L3), Mori (L3), Vane (L3)

[KEYWORD-TRIGGERED CHAINS]
├── Commander Voss (L3)
│   keywords: ["Commander Voss", "Voss", "Sera Voss"]
│   mentions: "eastern gate", "Davan Rhel", "Voss's blade"
│   → triggers: Eastern Gate (L4), Rhel (L3), Voss's Blade (L4)
├── Lt Rhel (L3)
│   keywords: ["Davan Rhel", "Rhel", "Lieutenant Rhel"]
│   mentions: "the armory", "Commander Voss"
│   → triggers: Vanguard Armory (L4), Voss (L3)
├── Eastern Gate (L4)
│   keywords: ["eastern gate", "the gate"]
│   mentions: "Iron Vanguard patrols"
│   → triggers: Iron Vanguard (L2, already loaded)
...
```

The recursion map serves three purposes:
1. **Pre-generation**: The agent and user can spot missing connections, dead-end entries
   (nothing triggers them), and keyword conflicts before generation starts
2. **During generation**: The agent references the map to ensure each entry mentions the
   right names in its prose, creating the intended keyword chains
3. **Post-generation audit**: The map becomes the spec that the audit checks against —
   every connection in the map must exist as a keyword in the final output

Present both sections together and wait for user confirmation. The user can modify
the recursion structure (add connections, remove entries, change what triggers what)
before generation starts.

For builds under 30 entries in standard mode, the checklist is optional — the normal
inventory confirmation in Step 6 is sufficient.

### Research-First Batch Loop (30+ entries or Full Detail Mode)

When the checklist is active, the standard between-batch verification (step 3 above) is
replaced by a more rigorous research-first two-pass cycle. Research and generation are
separate steps — The agent never generates an entry it hasn't just researched. This prevents
hallucination drift in long builds and ensures every entry benefits from fresh, verified
information.

**The loop for each batch:**

1. **Check the list** — Re-read the build list. Identify which entries are next in the
   queue (the next batch). Show the user what's about to be built.

2. **Verify the previous batch** — If this isn't the first batch, run web search
   verification on the entries that were just generated. Check names, relationships,
   timeline facts, and cultural details against source material. Flag and fix any
   errors before moving forward. This catches mistakes while the context is still warm.

3. **Check the list again** — Re-read the build list to confirm what's next. This
   second check prevents the model from losing track after the verification detour.
   Mark the verified batch as complete:
   ```
   [x] 4. Commander Voss — Character (L3) — Iron Vanguard — Alive ✓
   [x] 5. Eastern Gate — Location (L4) ✓
   → Next up: entries 6-10
   ```

4. **Research the next batch topics** — Before writing a single lorebook entry, do
   dedicated research on every topic in the upcoming batch. For known properties, run
   targeted web searches: character backgrounds, faction culture, location atmosphere,
   relationship dynamics. For original creations, re-read user-provided source material.
   Compile research notes internally — this is the foundation the entries will be built on.

5. **Generate the batch** — Now write the entries, drawing on the research just completed.
   Write to disk as a phase file. Update the manifest.

6. **Repeat from step 1** until the build list is fully checked off.

This loop means every batch gets: a position check, a backward verification pass, a
forward research pass, and then generation. It's slower but produces significantly
more accurate and richly detailed entries.

**Showing progress:** After each batch completes, show the user the updated checklist
with completed entries marked. This gives a clear sense of progress and lets the user
flag issues early rather than waiting until the end.

### Manifest Schema

The manifest keeps context lean between batches. It holds just enough to maintain
cross-references without reloading all prior phases into context. The agent re-reads the
manifest AND the recursion structure map (`worldbuild/recursion_map.md`)
between every batch to stay aligned on names, connections, and keyword chains:

```json
{
  "world_name": "...",
  "schema": 2,
  "time_period": "The build is set during [era/book/timeframe]",
  "total_planned_entries": 45,
  "generated_entries": 23,
  "next_id": 23,
  "phases_completed": 2,
  "recursion_map_path": "worldbuild/recursion_map.md",
  "characters": [
    {"id": 0, "name": "Commander Voss", "faction": "Iron Vanguard", "tier": "A", "layer": 3,
     "keywords": ["Commander Voss", "Voss", "Sera Voss"],
     "status": "alive", "active_period": "current era", "location": "Eastern Gate",
     "relationships": ["Davan Rhel (lieutenant)", "Nuno Cael (archivist)"]}
  ],
  "locations": [
    {"id": 15, "name": "Eastern Gate", "keywords": ["eastern gate", "the gate"],
     "culture_notes": "militaristic, disciplined, Vanguard-controlled"}
  ],
  "factions": [
    {"id": 1, "name": "Iron Vanguard", "members": ["Commander Voss", "Davan Rhel", "Nuno Cael"],
     "core_values": "order, discipline, duty above self"}
  ],
  "items": [],
  "rules": [],
  "keyword_index": {"Voss": 5, "eastern gate": 15},
  "insertion_order_used": [900, 950, 700, 400, 401]
}
```

### Batch Size Guidance

- Standard: ~10 entries per batch
- Full Detail Mode: ~5 entries per batch (entries are larger, need more attention)
- Character Mode (Schema 1): No batching needed — single card output
- Persona Mode: No batching needed — plain text output

Builds with **30+ entries** (any mode) or **Full Detail Mode** (any size) use the
pre-generation checklist and research-first batch loop described above. This adds
a verification and research pass to every batch cycle.

### Phase Organization

Organize batches for maximum coherence:

- **Phase 1**: Card shell + Layer 1 rules + Layer 2 faction anchors (these are usually <10 combined)
- **Phase 2**: Layer 3 Tier A characters (protagonist, antagonist, key cast)
- **Phase 3+**: Layer 3 Tier B characters, grouped by faction
- **Later phases**: Layer 4 locations, items, events, concepts
- **Final phase**: Layer 3 Tier C characters (minimal entries, can batch more densely)

**Full Detail Mode overrides this:** All characters are Tier A. Phase organization
is still by layer and faction for coherence, but no characters get reduced treatment.
See `references/full-detail.md` for the research-first batch loop and pre-generation
checklist that replace the standard flow.

### Error Recovery

If generation is interrupted mid-build:
- All completed phases are saved to disk
- Manifest tracks exactly where generation stopped
- User can say "continue building" and The agent picks up from the next ungenerated batch
- Merge script handles any number of phase files

### Post-Generation Audit

After merge and validation, Claude runs a three-pass audit against the build list and
recursion structure map. This is the safety net that catches everything that drifted
during long generation runs. The audit happens automatically — The agent does not present
the final file until all three passes are clean.

**Pass 1 — Entry name check**

Compare every entry name in the merged output against the build list. Check for:
- **Missing entries**: entries on the list that don't exist in the output
- **Extra entries**: entries in the output that aren't on the list (usually duplicates or
  entries generated under a slightly different name)
- **Name mismatches**: entries where the name drifted during generation (e.g. "Commander
  Voss" on the list became "Cmdr. Sera Voss" in the output — the entry exists but the
  name doesn't match)

Report: "All [N] entries accounted for" or list every discrepancy.

**Pass 2 — Keyword chain validation**

Using the recursion structure map as the spec, verify that the keyword chains actually
work in the generated output. For every connection in the recursion map, check:

1. **Does the source entry's content mention the target?** — If the map says Voss's entry
   should trigger Eastern Gate, check that Voss's `content` field actually contains
   "eastern gate" (or one of Eastern Gate's keywords). If the name isn't in the prose,
   the recursion chain is broken — it won't fire.

2. **Does the target entry have the right keywords?** — Check that Eastern Gate's `keys`
   (Schema 2) or `key` (Schema 3) array contains the keyword that would be triggered by
   the mention in the source entry. If Voss mentions "the eastern gate" but Eastern Gate's
   keywords are only `["Eastern Gate"]` without "the eastern gate", it may not fire.

3. **Are there orphan entries?** — Entries that nothing triggers (no constant flag, and no
   other entry mentions any of their keywords). These entries will never load in chat.
   Constant entries (Layer 1, Layer 2) are exempt — they're always loaded.

4. **Are there keyword collisions?** — Two entries sharing a keyword where only one should
   fire. Check against the recursion map to see if the collision is intentional (both
   should fire) or a bug.

Report each broken chain, orphan, and collision.

**Pass 3 — Auto-correction**

For every issue found in Passes 1 and 2, The agent fixes it directly in the merged output:

- **Missing entries**: Re-generate the missing entry and insert it with the correct ID,
  keywords, and content. Reference the recursion map for what it should contain and
  who should mention it.
- **Name mismatches**: Update the entry's `comment` field and keyword array to match the
  build list name. If the content uses the wrong name internally, fix the prose.
- **Broken keyword chains**: Two possible fixes depending on the problem:
  - If the source entry's prose doesn't mention the target: add a natural mention of the
    target's name into the source entry's content. Don't just append it — weave it into
    existing prose (relationships, location references, item mentions).
  - If the target's keyword array is missing a variant: add the missing keyword variant.
- **Orphan entries**: Identify which entry SHOULD trigger the orphan (based on the
  recursion map) and add a mention to that entry's content, or add the orphan's keyword
  to a relevant faction anchor.
- **Keyword collisions**: Add secondary keys to disambiguate, or adjust primary keywords
  to be more specific.

After corrections, re-run the validation script to ensure the fixes didn't break JSON
structure. Then write the corrected output to disk.

If corrections were needed, briefly report what was fixed:
"Fixed 3 issues: added missing entry 'Vanguard Armory', fixed broken chain Voss → Eastern
Gate (added keyword variant), resolved keyword collision on 'The Crown'."

Only after all three passes are clean does Claude proceed to present the final file.

#### Saving the Recursion Map

Write the recursion structure map to `worldbuild/recursion_map.md` alongside
the final output. This serves as documentation — the user can reference it later to
understand how their lorebook is wired, and it's useful if they come back to add entries
later (they can see where new entries should connect).

---

## Lorebook Update & Merge Workflow

When user pastes an existing lorebook or asks to add entries:

1. Parse: schema type, highest id/uid, highest insertion_order, all keywords, faction rosters
2. Present summary: "[X] entries (Schema [2/3]). New entries start from id [N+1]."
3. Run normal inventory workflow for NEW content only
4. Generate new entries using batch pipeline, starting IDs from next available
5. Merge new entries into existing JSON

## Card Iteration & Modification Workflow

Real-world card usage involves ongoing iteration — not just building from scratch.
When a user comes back with an existing card or lorebook and wants changes:

**Modifying existing entries** (e.g. "this character's personality isn't landing right"):
1. Parse the existing JSON and identify the entry to modify
2. Show the user the current content of the entry
3. Ask what should change and why — understanding the problem helps craft a better fix
4. Rewrite the entry, maintaining all structural fields (id, uid, keywords, position,
   constant, insertion_order/order, etc.) — only change the `content` and related prose
5. If the change affects relationships or keywords, propagate: check if other entries
   reference this one and update their prose if the change creates contradictions
6. Present the modified JSON with a diff summary: "Changed: Voss's personality section.
   Updated: Rhel's relationship mention to match."

**Adding to an existing world** (e.g. "add three more NPCs to the tavern"):
Use the Lorebook Update & Merge Workflow above, but also:
1. Check the recursion map (if available) or build one from the existing entries
2. Wire new entries into existing keyword chains — new NPCs should be named in
   the relevant location entry, faction anchor should be updated with new members
3. Verify no keyword collisions with existing entries

**Versioning**: Increment `character_version` in the card data on every modification.
Use date strings (e.g. "2026-04-14") or semantic versions (e.g. "1.2.0"). The
`modification_date` timestamp (V3) should be updated to current time.

---

## Prompt Placement & SillyTavern Settings

When generating cards, read `references/prompt-placement.md` for guidance on:
- When to use `system_prompt` vs `post_history_instructions` vs `creator_notes`
- Talkativeness values per character type (especially for Group Chat Mode)
- Context size recommendations based on lorebook complexity
- Post-generation settings that account for API/model differences

Include context size and talkativeness recommendations in STEP 9 post-generation output.

---

## Advanced ST Features (Out of Scope)

The following SillyTavern features exist but are intentionally not covered by this skill.
They're deep power-user territory and documenting them would add complexity that most
builds don't need:

- **ST regex scripts** — Pattern-based text replacement in AI output (censoring,
  formatting, dynamic text swaps). Configured per-character in ST, not in card JSON.
- **STScript / Quick Replies / macros** — Scripting commands embedded in cards or
  triggered via slash commands. Enables dynamic variables, conditional logic, and
  automated actions.
- **Timed effects and automations** — Time-based entry activation, scheduled events.

If a user asks about these features, note they exist and are configured in SillyTavern's
UI rather than in the card/lorebook JSON this skill generates.

---

## Error Blacklist

Read `references/error-blacklist.md` before final validation. Contains the full list of
schema errors, architecture errors, writing errors, and consistency errors to check against.

---

## Output Splitting (Group Chat Mode)

Group Chat Mode produces multiple files:
- Individual character cards (Schema 1) — one file per character
- Shared lorebook (Schema 3) — one file
- All written to disk, all presented to user as downloads
