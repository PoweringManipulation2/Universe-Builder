#!/usr/bin/env python3
"""
merge_phases.py — Merges phased WorldBuilder output into a single valid JSON file.

Usage:
    python merge_phases.py <build_dir> --schema <2|3> [--output <path>]

    build_dir: directory containing phase-01.json, phase-02.json, etc.
    --schema:  2 for embedded lorebook (World Mode), 3 for standalone (Lorebook Mode)
    --output:  output file path (default: <build_dir>/final_output.json)

Phase 1 must contain the complete card/lorebook shell.
Subsequent phases contain only the new entries for that batch.
"""

import json
import sys
import os
import glob
import argparse
import re


def load_json(path):
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def save_json(data, path):
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    print(f"Saved: {path}")


def get_phase_files(build_dir):
    """Find and sort phase files numerically."""
    pattern = os.path.join(build_dir, "phase-*.json")
    files = glob.glob(pattern)
    # Sort by phase number
    def phase_num(f):
        match = re.search(r'phase-(\d+)', os.path.basename(f))
        return int(match.group(1)) if match else 0
    return sorted(files, key=phase_num)


def merge_schema2(build_dir, output_path):
    """Merge Schema 2 (embedded lorebook) phases."""
    phase_files = get_phase_files(build_dir)
    if not phase_files:
        print("ERROR: No phase files found.")
        sys.exit(1)

    print(f"Found {len(phase_files)} phase files.")

    # Phase 1 is the complete card shell with initial entries
    card = load_json(phase_files[0])
    print(f"Phase 1: loaded card shell with "
          f"{len(card.get('data', {}).get('character_book', {}).get('entries', []))} entries")

    # Ensure entries list exists
    entries = card.get('data', {}).get('character_book', {}).get('entries', [])

    # Track IDs for collision detection
    used_ids = set()
    for entry in entries:
        eid = entry.get('id')
        uid = entry.get('extensions', {}).get('uid')
        if eid is not None:
            used_ids.add(eid)
        if uid is not None:
            used_ids.add(uid)

    # Merge subsequent phases
    for phase_path in phase_files[1:]:
        phase_data = load_json(phase_path)
        phase_name = os.path.basename(phase_path)

        # Phase data can be: a list of entries, or {"entries": [...]}
        if isinstance(phase_data, list):
            new_entries = phase_data
        elif isinstance(phase_data, dict) and 'entries' in phase_data:
            new_entries = phase_data['entries']
        else:
            print(f"WARNING: {phase_name} has unexpected format, skipping.")
            continue

        # Check for ID collisions
        for entry in new_entries:
            eid = entry.get('id')
            if eid in used_ids:
                print(f"WARNING: Duplicate id {eid} in {phase_name}")
            used_ids.add(eid)

        entries.extend(new_entries)
        print(f"{phase_name}: added {len(new_entries)} entries (total: {len(entries)})")

    # Write back
    card['data']['character_book']['entries'] = entries
    save_json(card, output_path)

    # Summary
    print(f"\nMerge complete: {len(entries)} total entries")
    constants = sum(1 for e in entries if e.get('constant', False))
    print(f"  Constant entries: {constants}")
    print(f"  Keyword-triggered: {len(entries) - constants}")
    return card


def merge_schema3(build_dir, output_path):
    """Merge Schema 3 (standalone lorebook) phases."""
    phase_files = get_phase_files(build_dir)
    if not phase_files:
        print("ERROR: No phase files found.")
        sys.exit(1)

    print(f"Found {len(phase_files)} phase files.")

    # Phase 1 is the complete lorebook shell with initial entries
    lorebook = load_json(phase_files[0])
    print(f"Phase 1: loaded lorebook shell with "
          f"{len(lorebook.get('entries', {}))} entries")

    entries = lorebook.get('entries', {})
    used_keys = set(entries.keys())

    # Merge subsequent phases
    for phase_path in phase_files[1:]:
        phase_data = load_json(phase_path)
        phase_name = os.path.basename(phase_path)

        # Phase data can be: {"entries": {"N": {...}, ...}} or just {"N": {...}, ...}
        if isinstance(phase_data, dict) and 'entries' in phase_data:
            new_entries = phase_data['entries']
        elif isinstance(phase_data, dict):
            # Assume it's a flat dict of entries
            new_entries = phase_data
        else:
            print(f"WARNING: {phase_name} has unexpected format, skipping.")
            continue

        # Check for key collisions
        for key in new_entries:
            if key in used_keys:
                print(f"WARNING: Duplicate object key '{key}' in {phase_name}")
            used_keys.add(key)

        entries.update(new_entries)
        print(f"{phase_name}: added {len(new_entries)} entries (total: {len(entries)})")

    lorebook['entries'] = entries
    save_json(lorebook, output_path)

    # Summary
    print(f"\nMerge complete: {len(entries)} total entries")
    constants = sum(1 for e in entries.values() if e.get('constant', False))
    print(f"  Constant entries: {constants}")
    print(f"  Keyword-triggered: {len(entries) - constants}")
    return lorebook


def main():
    parser = argparse.ArgumentParser(description="Merge WorldBuilder phase files")
    parser.add_argument('build_dir', help="Directory containing phase-NN.json files")
    parser.add_argument('--schema', type=int, required=True, choices=[2, 3],
                        help="Schema type: 2 (embedded) or 3 (standalone)")
    parser.add_argument('--output', default=None,
                        help="Output path (default: <build_dir>/final_output.json)")
    args = parser.parse_args()

    build_dir = args.build_dir
    output_path = args.output or os.path.join(build_dir, "final_output.json")

    if args.schema == 2:
        merge_schema2(build_dir, output_path)
    else:
        merge_schema3(build_dir, output_path)

    print(f"\nOutput: {output_path}")
    print("Run validate_output.py to verify the merged file.")


if __name__ == '__main__':
    main()
