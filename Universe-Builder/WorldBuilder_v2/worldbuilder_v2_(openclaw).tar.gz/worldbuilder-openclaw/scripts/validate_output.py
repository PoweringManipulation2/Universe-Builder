#!/usr/bin/env python3
"""
validate_output.py — Validates a WorldBuilder JSON output file.

Usage:
    python validate_output.py <json_file> [--schema <2|3>]

Checks:
  - Valid JSON
  - Correct schema structure
  - Unique IDs/UIDs
  - No keyword collisions between entries
  - Relationship reciprocation (flags one-way references)
  - Required fields present
  - Constant/prevent_recursion consistency with layer assignments
  - Insertion order uniqueness
"""

import json
import sys
import os
import re
import argparse
from collections import Counter, defaultdict


def load_json(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except json.JSONDecodeError as e:
        print(f"FATAL: Invalid JSON — {e}")
        sys.exit(1)


def detect_schema(data):
    """Auto-detect schema type from structure."""
    if 'data' in data and 'character_book' in data.get('data', {}):
        return 2
    if 'entries' in data and isinstance(data['entries'], dict):
        return 3
    if 'data' in data and 'character_book' not in data.get('data', {}):
        return 1
    return None


def get_entries(data, schema):
    """Extract entries list regardless of schema."""
    if schema == 2:
        return data.get('data', {}).get('character_book', {}).get('entries', [])
    elif schema == 3:
        return list(data.get('entries', {}).values())
    return []


def get_entry_name(entry, schema):
    """Get human-readable name from entry."""
    return entry.get('comment', entry.get('id', '?'))


def get_keywords(entry, schema):
    """Get primary keywords from entry."""
    if schema == 2:
        return entry.get('keys', [])
    return entry.get('key', [])


def get_secondary_keywords(entry, schema):
    if schema == 2:
        return entry.get('secondary_keys', [])
    return entry.get('keysecondary', [])


def get_insertion_order(entry, schema):
    if schema == 2:
        return entry.get('insertion_order', None)
    return entry.get('order', None)


def validate(data, schema):
    errors = []
    warnings = []
    entries = get_entries(data, schema)

    if not entries:
        errors.append("No entries found in output.")
        return errors, warnings

    print(f"Validating {len(entries)} entries (Schema {schema})...\n")

    # --- ID uniqueness ---
    if schema == 2:
        ids = [e.get('id') for e in entries]
        uids = [e.get('extensions', {}).get('uid') for e in entries]
        id_dupes = [k for k, v in Counter(ids).items() if v > 1]
        uid_dupes = [k for k, v in Counter(uids).items() if v > 1]
        if id_dupes:
            errors.append(f"Duplicate id values: {id_dupes}")
        if uid_dupes:
            errors.append(f"Duplicate uid values: {uid_dupes}")
    elif schema == 3:
        uids = [e.get('uid') for e in entries]
        uid_dupes = [k for k, v in Counter(uids).items() if v > 1]
        if uid_dupes:
            errors.append(f"Duplicate uid values: {uid_dupes}")
        # Check object keys
        obj_keys = list(data.get('entries', {}).keys())
        key_dupes = [k for k, v in Counter(obj_keys).items() if v > 1]
        if key_dupes:
            errors.append(f"Duplicate object keys: {key_dupes}")

    # --- Required fields ---
    for entry in entries:
        name = get_entry_name(entry, schema)
        content = entry.get('content', '')
        if not content or len(content.strip()) < 10:
            warnings.append(f"'{name}' has empty or minimal content")

        if schema == 2:
            if 'enabled' not in entry:
                errors.append(f"'{name}' missing 'enabled' field (will be disabled on import)")
            elif entry.get('enabled') is not True:
                warnings.append(f"'{name}' has enabled=false — intentional?")

        keywords = get_keywords(entry, schema)
        if not keywords:
            warnings.append(f"'{name}' has no keywords")

    # --- Keyword collision detection ---
    keyword_map = defaultdict(list)
    for entry in entries:
        name = get_entry_name(entry, schema)
        for kw in get_keywords(entry, schema):
            kw_lower = kw.lower()
            keyword_map[kw_lower].append(name)

    for kw, owners in keyword_map.items():
        if len(owners) > 1:
            # Check if entries with shared keywords use secondary keys
            has_selective = True
            for entry in entries:
                ename = get_entry_name(entry, schema)
                if ename in owners:
                    sk = get_secondary_keywords(entry, schema)
                    if not sk:
                        has_selective = False
            if not has_selective:
                warnings.append(
                    f"Keyword '{kw}' shared by [{', '.join(owners)}] without secondary keys"
                )

    # --- Insertion order uniqueness ---
    orders = []
    for entry in entries:
        io = get_insertion_order(entry, schema)
        if io is not None:
            orders.append((io, get_entry_name(entry, schema)))
    order_vals = [o[0] for o in orders]
    order_dupes = [k for k, v in Counter(order_vals).items() if v > 1]
    if order_dupes:
        for dupe_val in order_dupes:
            dupe_names = [n for o, n in orders if o == dupe_val]
            warnings.append(
                f"Insertion order {dupe_val} shared by [{', '.join(dupe_names)}]"
            )

    # --- Layer consistency checks ---
    for entry in entries:
        name = get_entry_name(entry, schema)
        is_constant = entry.get('constant', False)
        io = get_insertion_order(entry, schema)
        pr = entry.get('prevent_recursion', entry.get('preventRecursion', False))

        if io is not None:
            # Layer 2 faction anchors should NOT have prevent_recursion
            if 700 <= io <= 899 and pr:
                errors.append(f"'{name}' is a faction anchor (order {io}) with prevent_recursion=true — this breaks recursion chains")

            # Layer 1 rules should be constant
            if 900 <= io <= 999 and not is_constant:
                warnings.append(f"'{name}' is in rule tier (order {io}) but not constant")

            # Layer 2 anchors should be constant
            if 700 <= io <= 899 and not is_constant:
                warnings.append(f"'{name}' is in anchor tier (order {io}) but not constant")

    # --- Schema-specific field checks ---
    if schema == 3:
        for entry in entries:
            name = get_entry_name(entry, schema)
            # Check for Schema 2 field names in Schema 3
            if 'keys' in entry:
                errors.append(f"'{name}' uses 'keys' (Schema 2) instead of 'key' (Schema 3)")
            if 'secondary_keys' in entry:
                errors.append(f"'{name}' uses 'secondary_keys' instead of 'keysecondary'")
            if 'insertion_order' in entry:
                errors.append(f"'{name}' uses 'insertion_order' instead of 'order'")
            pos = entry.get('position')
            if isinstance(pos, str):
                errors.append(f"'{name}' has string position '{pos}' — Schema 3 uses integers (0 or 1)")

    if schema == 2:
        # Check recursive_scanning is on
        cb = data.get('data', {}).get('character_book', {})
        if not cb.get('recursive_scanning', False):
            errors.append("recursive_scanning is false — recursion chains won't work")

    # --- Relationship reciprocation check ---
    # Build a map of which entries reference which names
    entry_names = set()
    for entry in entries:
        comment = entry.get('comment', '')
        # Extract name from comment (usually "Name - Category")
        if ' - ' in comment:
            entry_names.add(comment.split(' - ')[0].strip())
        else:
            entry_names.add(comment.strip())

    # This is a soft check — just flag potential issues
    name_mentions = defaultdict(set)
    for entry in entries:
        ename = get_entry_name(entry, schema)
        content = entry.get('content', '')
        for other_name in entry_names:
            if other_name and other_name != ename.split(' - ')[0].strip():
                if other_name.lower() in content.lower():
                    name_mentions[ename].add(other_name)

    # --- recursive_scanning global check for Schema 3 ---
    if schema == 3:
        if not data.get('recursive_scanning', False):
            errors.append("recursive_scanning is false — recursion chains won't work")

    return errors, warnings


def main():
    parser = argparse.ArgumentParser(description="Validate WorldBuilder output")
    parser.add_argument('json_file', help="Path to JSON file to validate")
    parser.add_argument('--schema', type=int, choices=[1, 2, 3], default=None,
                        help="Schema type (auto-detected if not specified)")
    args = parser.parse_args()

    data = load_json(args.json_file)

    schema = args.schema or detect_schema(data)
    if schema is None:
        print("ERROR: Cannot detect schema type. Use --schema flag.")
        sys.exit(1)

    if schema == 1:
        print("Schema 1 (character card) — minimal validation needed.")
        # Just check it's valid JSON with required fields
        required = ['name', 'description', 'first_mes']
        d = data.get('data', data)
        missing = [f for f in required if not d.get(f)]
        if missing:
            print(f"WARNING: Missing fields: {missing}")
        else:
            print("✅ All required fields present.")
        return

    errors, warnings = validate(data, schema)

    if errors:
        print(f"❌ {len(errors)} ERROR(S):")
        for e in errors:
            print(f"  ✘ {e}")

    if warnings:
        print(f"\n⚠️  {len(warnings)} WARNING(S):")
        for w in warnings:
            print(f"  ⚡ {w}")

    if not errors and not warnings:
        print("✅ All checks passed!")
    elif not errors:
        print(f"\n✅ No errors (but {len(warnings)} warnings to review)")
    else:
        print(f"\n❌ Fix {len(errors)} error(s) before importing")


if __name__ == '__main__':
    main()
